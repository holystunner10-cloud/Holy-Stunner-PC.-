package com.example.model

enum class CompatibilityMode(val title: String, val description: String, val tag: String) {
    WINDOWS_11_X64("Windows 11 (64-bit PE)", "Native 64-bit Windows execution with DirectX 12 API hooks", "Win11 x64"),
    WINDOWS_10_WOW64("Windows 10 (WoW64 32-bit)", "WoW64 translation layer for 32-bit legacy PC applications", "Win10 x86"),
    WINDOWS_7_SP1("Windows 7 SP1 (Win32)", "High compatibility fallback for classic desktop tools and games", "Win7 SP1"),
    POSIX_LINUX("POSIX Linux Runtime", "ELF64 binary runner with standard glibc & system call translation", "Linux ELF"),
    PYTHON_INTERPRETER("Python 3.12 Engine", "Sandboxed Python runtime with standard library modules", "Python 3.12"),
    BATCH_CMD_ENGINE("Windows CMD / Batch", "Windows NT command processor with pipe & redirection support", "CMD / BAT")
}

data class OptimizationProfile(
    val name: String,
    val isEnabled: Boolean,
    val performanceImpact: String,
    val description: String
)

data class Win32ApiTrace(
    val timestamp: Long,
    val functionName: String,
    val parameters: String,
    val returnValue: String,
    val status: String = "SUCCESS"
)

data class ProgramTestReport(
    val programName: String,
    val mode: CompatibilityMode,
    val exitCode: Int,
    val executionTimeMs: Long,
    val instructionCount: Long,
    val peakMemoryKb: Long,
    val stdout: String,
    val stderr: String = "",
    val apiTraces: List<Win32ApiTrace> = emptyList(),
    val optimizationNotes: List<String> = emptyList()
)
