package com.example.model

enum class Sender {
    USER,
    HOLY_AI,
    SYSTEM
}

data class HolyAiMessage(
    val id: String,
    val sender: Sender,
    val text: String,
    val codeSnippet: String? = null,
    val codeLanguage: String? = null,
    val suggestedCommand: String? = null,
    val actionAppId: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isStreaming: Boolean = false
)

data class SystemMetrics(
    val cpuUsagePercent: Int = 24,
    val ramUsedMb: Int = 3840,
    val ramTotalMb: Int = 16384,
    val storageUsedGb: Float = 142.5f,
    val storageTotalGb: Float = 512.0f,
    val cpuTempC: Int = 42,
    val batteryPercent: Int = 92,
    val isCharging: Boolean = true,
    val wifiConnected: Boolean = true,
    val wifiSsid: String = "HolyStunner-5G-Ultra",
    val soundVolume: Float = 0.8f,
    val currentWallpaper: String = "cyber",
    val performanceMode: String = "Turbo Ultra"
) {
    val ramUsedGb: Float get() = ramUsedMb / 1024f
    val ramTotalGb: Float get() = ramTotalMb / 1024f
}
