package com.example.model

data class UserProfile(
    val id: String = "user_default",
    val email: String = "holystunner10@gmail.com",
    val displayName: String = "Holy Stunner",
    val photoUrl: String? = null,
    val role: String = "Administrator / Root Hypervisor",
    val isAuthenticated: Boolean = true,
    val signInProvider: String = "Google Account",
    val loginTime: Long = System.currentTimeMillis(),
    val vmAllocatedMemoryMb: Int = 16384,
    val privileges: List<String> = listOf(
        "RING_0_KERNEL_ACCESS",
        "DIRECT_HARDWARE_EMULATION",
        "DYNAMIC_COMPATIBILITY_RECOMPILER",
        "AI_NEURAL_COPROCESSOR_ADMIN",
        "FILESYSTEM_ROOT_WRITE"
    )
)
