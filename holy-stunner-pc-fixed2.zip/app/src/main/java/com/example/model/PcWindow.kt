package com.example.model

data class PcWindow(
    val id: String,
    val appId: String,
    val title: String,
    val iconName: String,
    var x: Float = 40f,
    var y: Float = 40f,
    var width: Float = 600f,
    var height: Float = 440f,
    var zIndex: Float = 1f,
    var isMinimized: Boolean = false,
    var isMaximized: Boolean = false,
    var isOpen: Boolean = true,
    var payload: Any? = null
)

data class WindowRect(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float
)
