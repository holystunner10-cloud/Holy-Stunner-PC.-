package com.example.model

import androidx.compose.ui.graphics.Color

enum class WallpaperThemeType {
    GREEN_TEXT_HOLY_STUNNER,
    CYBER_GRID,
    NEON_HORIZON,
    QUANTUM_NEBULA,
    EMERALD_CRT
}

data class PcWallpaper(
    val id: String,
    val name: String,
    val type: WallpaperThemeType,
    val gradientColors: List<Color>,
    val accentColor: Color,
    val previewDescription: String
)

val defaultWallpapers = listOf(
    PcWallpaper(
        id = "green_text_holy_stunner",
        name = "Green Text Holy Stunner",
        type = WallpaperThemeType.GREEN_TEXT_HOLY_STUNNER,
        gradientColors = listOf(Color(0xFF03160B), Color(0xFF010A05)),
        accentColor = Color(0xFF10B981),
        previewDescription = "Glowing emerald typography & cyber digital matrix"
    ),
    PcWallpaper(
        id = "cyber_grid",
        name = "Midnight Slate Grid",
        type = WallpaperThemeType.CYBER_GRID,
        gradientColors = listOf(Color(0xFF111318), Color(0xFF07090C)),
        accentColor = Color(0xFF06B6D4),
        previewDescription = "Deep slate with cyan geometric lines"
    ),
    PcWallpaper(
        id = "neon_horizon",
        name = "Neon Cyber Horizon",
        type = WallpaperThemeType.NEON_HORIZON,
        gradientColors = listOf(Color(0xFF1B1626), Color(0xFF0F0C16)),
        accentColor = Color(0xFFA855F7),
        previewDescription = "Electric indigo & violet neon glow"
    ),
    PcWallpaper(
        id = "quantum_nebula",
        name = "Deep Quantum Nebula",
        type = WallpaperThemeType.QUANTUM_NEBULA,
        gradientColors = listOf(Color(0xFF141923), Color(0xFF0B0E14)),
        accentColor = Color(0xFF3B82F6),
        previewDescription = "Stellar deep space & quantum dust"
    ),
    PcWallpaper(
        id = "emerald_crt",
        name = "Emerald CRT Terminal",
        type = WallpaperThemeType.EMERALD_CRT,
        gradientColors = listOf(Color(0xFF052313), Color(0xFF020E08)),
        accentColor = Color(0xFF22C55E),
        previewDescription = "Phosphor scanlines & vintage terminal glow"
    )
)
