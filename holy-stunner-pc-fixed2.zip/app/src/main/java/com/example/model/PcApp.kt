package com.example.model

import androidx.compose.ui.graphics.Color

enum class AppCategory(val title: String) {
    SYSTEM("System & Core"),
    PRODUCTIVITY("Productivity & Dev"),
    CREATIVE("Creative & Design"),
    MEDIA("Media & Web"),
    GAMES("Games & Fun"),
    UTILITIES("Tools & Utilities")
}

data class PcApp(
    val id: String,
    val name: String,
    val iconName: String,
    val description: String,
    val category: AppCategory,
    val sizeMb: Int,
    val version: String,
    val isInstalled: Boolean = true,
    val isDefault: Boolean = false,
    val installProgress: Float = 1.0f,
    val isInstalling: Boolean = false,
    val accentColor: Long = 0xFF6366F1,
    val defaultWidth: Float = 640f,
    val defaultHeight: Float = 480f
)
