package com.example.model

enum class FileType {
    TEXT,
    PYTHON,
    BATCH,
    EXECUTABLE,
    IMAGE,
    AUDIO,
    SYSTEM,
    FOLDER
}

data class PcFileItem(
    val id: String,
    val name: String,
    val path: String,
    val type: FileType,
    val sizeBytes: Long = 1024,
    val content: String = "",
    val lastModified: Long = System.currentTimeMillis(),
    val iconName: String = "file"
)

data class DesktopIcon(
    val id: String,
    val title: String,
    val iconName: String,
    val appId: String? = null,
    val filePath: String? = null,
    val gridCol: Int,
    val gridRow: Int,
    val accentColor: Long = 0xFF38BDF8
)
