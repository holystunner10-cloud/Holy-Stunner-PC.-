package com.example.model

enum class VmStatus {
    RUNNING,
    PAUSED,
    OPTIMIZING,
    REBOOTING
}

data class CpuCoreMetric(
    val coreId: Int,
    val clockGhz: Float = 4.80f,
    val loadPercent: Int = 18,
    val temperatureC: Int = 42,
    val currentThread: String = "dwm.exe"
)

data class CpuRegisters(
    val rax: String = "0x00007FF6_B4A01020",
    val rbx: String = "0x00000000_00000001",
    val rcx: String = "0x000001D4_2C804000",
    val rdx: String = "0x00000000_00000020",
    val rsi: String = "0x000001D4_2C804250",
    val rdi: String = "0x00007FF6_B4A05000",
    val rsp: String = "0x000000C8_567FE4A0",
    val rbp: String = "0x000000C8_567FE500",
    val rip: String = "0x00007FF6_B4A01540",
    val flags: String = "CF=0 ZF=1 SF=0 OF=0 IF=1"
)

data class MemoryPage(
    val address: String,
    val type: String,
    val sizeKb: Int,
    val protection: String,
    val module: String
)

data class VmSnapshot(
    val id: String,
    val name: String,
    val timestamp: Long,
    val ramUsedMb: Int,
    val description: String
)

data class VirtualMachineState(
    val status: VmStatus = VmStatus.RUNNING,
    val hypervisorName: String = "Holy Stunner Micro-Hypervisor v4.2 (KVM/VT-x Emulation)",
    val architecture: String = "x86_64 / ARM64-EC Hybrid",
    val uptimeSeconds: Long = 18420,
    val totalCores: Int = 16,
    val activeThreads: Int = 142,
    val coreMetrics: List<CpuCoreMetric> = List(16) { i ->
        CpuCoreMetric(coreId = i, loadPercent = (12..35).random(), temperatureC = (40..46).random())
    },
    val registers: CpuRegisters = CpuRegisters(),
    val totalRamMb: Int = 16384,
    val usedRamMb: Int = 3840,
    val pagedPoolMb: Int = 620,
    val nonPagedPoolMb: Int = 380,
    val pageFaultsPerSec: Int = 14,
    val vDiskCapacityGb: Float = 512f,
    val vDiskUsedGb: Float = 142.5f,
    val vDiskReadMbs: Float = 3450.0f,
    val vDiskWriteMbs: Float = 2800.0f,
    val activeIrq: String = "IRQ 0 (High Precision Event Timer - HPET)",
    val memoryPages: List<MemoryPage> = listOf(
        MemoryPage("0x00007FF6_B4000000", "Image (PE Header)", 4096, "PAGE_READONLY", "ntoskrnl.exe"),
        MemoryPage("0x00007FF6_B4A00000", "Code (.text)", 16384, "PAGE_EXECUTE_READ", "kernel32.dll"),
        MemoryPage("0x000001D4_2C800000", "Heap (Dynamic)", 32768, "PAGE_READWRITE", "holystunner_vm.bin"),
        MemoryPage("0x000000C8_56700000", "Stack (Thread 0)", 1024, "PAGE_READWRITE", "user32.dll"),
        MemoryPage("0x00007FFA_C1200000", "Virtual MMIO", 8192, "PAGE_READWRITE", "dxgi.dll")
    ),
    val snapshots: List<VmSnapshot> = listOf(
        VmSnapshot("snap_1", "Clean Boot Baseline", System.currentTimeMillis() - 86400000, 3200, "Clean Windows OS initialization"),
        VmSnapshot("snap_2", "Dev Environment Ready", System.currentTimeMillis() - 3600000, 3840, "VS Code & Python 3.12 runtime loaded")
    )
)
