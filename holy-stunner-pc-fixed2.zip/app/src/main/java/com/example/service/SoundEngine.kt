package com.example.service

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

object SoundEngine {
    private var isMuted: Boolean = false
    private val scope = CoroutineScope(Dispatchers.Default)

    fun setMuted(muted: Boolean) {
        isMuted = muted
    }

    fun playClick() {
        if (isMuted) return
        scope.launch {
            playToneSequence(listOf(Pair(1200, 30)))
        }
    }

    fun playWindowOpen() {
        if (isMuted) return
        scope.launch {
            playToneSequence(listOf(Pair(523, 40), Pair(659, 50), Pair(784, 70)))
        }
    }

    fun playWindowClose() {
        if (isMuted) return
        scope.launch {
            playToneSequence(listOf(Pair(784, 40), Pair(659, 40), Pair(523, 50)))
        }
    }

    fun playBootChime() {
        if (isMuted) return
        scope.launch {
            playToneSequence(
                listOf(
                    Pair(440, 100),
                    Pair(554, 120),
                    Pair(659, 140),
                    Pair(880, 300)
                )
            )
        }
    }

    fun playSuccess() {
        if (isMuted) return
        scope.launch {
            playToneSequence(listOf(Pair(587, 80), Pair(880, 150)))
        }
    }

    fun playError() {
        if (isMuted) return
        scope.launch {
            playToneSequence(listOf(Pair(300, 100), Pair(200, 150)))
        }
    }

    private fun playToneSequence(tones: List<Pair<Int, Int>>) {
        try {
            val sampleRate = 22050
            var totalSamples = 0
            for ((_, durationMs) in tones) {
                totalSamples += (sampleRate * durationMs / 1000)
            }

            val buffer = ShortArray(totalSamples)
            var offset = 0

            for ((freq, durationMs) in tones) {
                val samplesForTone = sampleRate * durationMs / 1000
                for (i in 0 until samplesForTone) {
                    val angle = 2.0 * Math.PI * i / (sampleRate.toDouble() / freq)
                    val envelope = 1.0 - (i.toDouble() / samplesForTone)
                    val sample = (sin(angle) * envelope * Short.MAX_VALUE * 0.45).toInt().toShort()
                    buffer[offset + i] = sample
                }
                offset += samplesForTone
            }

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(buffer, 0, buffer.size)
            track.play()
            track.setNotificationMarkerPosition(buffer.size)
            track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(t: AudioTrack?) {
                    t?.release()
                }
                override fun onPeriodicNotification(t: AudioTrack?) {}
            })
        } catch (_: Exception) {
            // Ignored on audio devices that restrict direct PCM
        }
    }
}
