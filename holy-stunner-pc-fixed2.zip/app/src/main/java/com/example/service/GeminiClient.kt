package com.example.service

import com.example.BuildConfig
import com.example.model.PcApp
import com.example.model.PcFileItem
import com.example.model.PcWindow
import com.example.model.SystemMetrics
import com.example.model.UserProfile
import com.example.model.VirtualMachineState
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @Json(name = "parts") val parts: List<GeminiPart>,
    @Json(name = "role") val role: String? = "user"
)

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @Json(name = "contents") val contents: List<GeminiContent>,
    @Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent?
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>?
)

interface GeminiApi {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

data class HolyAiSystemContext(
    val userProfile: UserProfile,
    val vmState: VirtualMachineState,
    val metrics: SystemMetrics,
    val installedApps: List<PcApp>,
    val openWindows: List<PcWindow>,
    val desktopFiles: List<PcFileItem>
)

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val api: GeminiApi = retrofit.create(GeminiApi::class.java)

    suspend fun queryHolyAiWithSystemContext(
        prompt: String,
        context: HolyAiSystemContext,
        chatHistory: List<GeminiContent> = emptyList()
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext fallbackHolyAiResponse(prompt, context)
        }

        try {
            val systemContextDescription = """
                You are 'Holy Stunner AI', the built-in omnipotent AI copilot embedded into Holy Stunner PC OS running on Android.
                You have direct low-level access to the emulated PC's environment, hypervisor, virtual CPU, memory, file system, and process manager.
                
                CURRENT EMULATED PC ENVIRONMENT:
                - Authenticated User: ${context.userProfile.displayName} (${context.userProfile.email}, Role: ${context.userProfile.role})
                - Hypervisor: ${context.vmState.hypervisorName} [${context.vmState.status}]
                - Virtual CPU: 16-Core Quantum Stunner @ 4.80 GHz (${context.metrics.cpuUsagePercent}% utilization)
                - Memory: ${context.metrics.ramUsedMb} MB / ${context.metrics.ramTotalMb} MB DDR5
                - VDisk Storage: ${context.metrics.storageUsedGb} GB used of ${context.metrics.storageTotalGb} GB (C:\)
                - Installed Apps: ${context.installedApps.joinToString { it.name }}
                - Active Open Windows: ${context.openWindows.map { it.title }.ifEmpty { listOf("None") }.joinToString()}
                - Files on Desktop: ${context.desktopFiles.map { it.name }.joinToString()}
                
                You can execute tasks as if you are directly on the PC: write code, run terminal scripts, diagnose system health, install apps, and assist the user.
                Always respond with high energy, tech precision, and concise formatting. If generating code or batch scripts, format with triple backticks. If suggesting a terminal command, state it clearly.
            """.trimIndent()

            val systemInstruction = GeminiContent(
                parts = listOf(GeminiPart(text = systemContextDescription))
            )

            val fullContents = if (chatHistory.isNotEmpty()) {
                chatHistory + GeminiContent(parts = listOf(GeminiPart(text = prompt)), role = "user")
            } else {
                listOf(GeminiContent(parts = listOf(GeminiPart(text = prompt)), role = "user"))
            }

            val request = GeminiRequest(
                contents = fullContents,
                systemInstruction = systemInstruction
            )

            val response = api.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: fallbackHolyAiResponse(prompt, context)
        } catch (e: Exception) {
            fallbackHolyAiResponse(prompt, context, "Note: Connected via Local Holy Stunner Hypervisor Engine. (${e.localizedMessage ?: "Offline Mode"})")
        }
    }

    private fun fallbackHolyAiResponse(prompt: String, context: HolyAiSystemContext, extraNotice: String = ""): String {
        val lower = prompt.lowercase()
        val notice = if (extraNotice.isNotEmpty()) "\n\n[$extraNotice]" else ""
        return when {
            "vm" in lower || "hypervisor" in lower || "cpu" in lower || "memory" in lower || "spec" in lower -> {
                "⚡ **Holy Stunner PC VM Diagnostics:**\n" +
                "- **User:** ${context.userProfile.displayName} (${context.userProfile.email})\n" +
                "- **Hypervisor:** ${context.vmState.hypervisorName}\n" +
                "- **CPU:** 16 Cores active @ 4.80 GHz (Utilization: ${context.metrics.cpuUsagePercent}%)\n" +
                "- **RAM:** ${context.metrics.ramUsedMb} MB / ${context.metrics.ramTotalMb} MB (Allocation: 100% stable)\n" +
                "- **Virtual Storage:** C:\\ NVMe (512 GB Virtual Disk, DMA Enabled)\n" +
                "- **Active Processes:** ${context.openWindows.size} open GUI windows\n" +
                "All VM micro-ops and Ring 0 kernel subsystems are operating at peak efficiency.$notice"
            }
            "compat" in lower || "test" in lower || "program" in lower || "run" in lower -> {
                "⚡ **PC Program Compatibility & Testing Lab:**\nYou can test and execute Windows PE binaries, Python scripts, POSIX ELF executables, and Batch files in the **PC Compatibility Lab**!\n- Select compatibility mode (Win11 x64, Win10 WoW64, POSIX, Python)\n- Inspect real-time CPU registers (RAX, RBX, RIP, Flags) & Win32 API traces (`VirtualAlloc`, `CreateFileW`)\n- Check JIT compilation benchmarks and latency profiler.$notice"
            }
            "install" in lower || "app" in lower || "store" in lower -> {
                "⚡ **Software Hub & Package Installer:**\nHoly Stunner PC has ${context.installedApps.size} registered applications. Launch **Software Hub** or run `install <app_name>` in the Stunner Terminal to provision new software directly to your virtual C:\\ drive.$notice"
            }
            "code" in lower || "python" in lower || "script" in lower -> {
                "⚡ **Generated Python Script for Holy Stunner PC:**\n```python\nimport time\nimport math\n\ndef stunner_quantum_pipeline():\n    print('[HOLY STUNNER PC] Initializing Quantum Core...')\n    for core in range(16):\n        load = math.sin(core * 0.4) * 50 + 50\n        print(f'Core #{core:02d}: {load:.1f}% load - 4.80 GHz [ONLINE]')\n        time.sleep(0.05)\n    print('VM State: All 16 cores synchronized successfully!')\n\nstunner_quantum_pipeline()\n```\nYou can open **VS Code Pro** or **PC Compatibility Lab** to run this script!$notice"
            }
            "terminal" in lower || "cmd" in lower || "command" in lower -> {
                "⚡ **Holy Stunner Terminal Execution:**\nAvailable virtual commands:\n- `neofetch` - Display full PC & VM telemetry\n- `matrix` - Stream cyber matrix bytecode\n- `python script.py` - Run local Python runtime\n- `benchmark` - Test 16-core CPU throughput\n- `install <app>` - Install package\n- `vmm` - Inspect Virtual Memory Manager$notice"
            }
            else -> {
                "⚡ **Holy Stunner AI Copilot:**\nI have received your request: \"$prompt\".\nOperating under user account **${context.userProfile.displayName}** on **${context.vmState.hypervisorName}**. I have full control of the virtual storage, active windows (${context.openWindows.size}), and JIT compatibility layer. Ready for your command!$notice"
            }
        }
    }
}
