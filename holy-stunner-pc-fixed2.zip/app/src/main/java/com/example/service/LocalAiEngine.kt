package com.example.service

import com.example.model.FileType
import com.example.model.HolyAiMessage
import com.example.model.Sender
import java.util.UUID

sealed class LocalAiAction {
    data class OpenApp(val appId: String, val appName: String, val payload: Any? = null) : LocalAiAction()
    data class SetWallpaper(val wallpaperIndex: Int, val wallpaperName: String) : LocalAiAction()
    data class CreateFile(val fileName: String, val content: String, val fileType: FileType) : LocalAiAction()
    object OptimizeRam : LocalAiAction()
    object RebootPc : LocalAiAction()
    object MinimizeAllWindows : LocalAiAction()
    data class RunTerminalCommand(val command: String) : LocalAiAction()
    object None : LocalAiAction()
}

data class LocalAiResult(
    val responseText: String,
    val action: LocalAiAction = LocalAiAction.None,
    val codeSnippet: String? = null,
    val codeLanguage: String? = null,
    val suggestedCommand: String? = null
)

object LocalAiEngine {

    fun processIntent(prompt: String, context: HolyAiSystemContext): LocalAiResult {
        val lower = prompt.trim().lowercase()

        // 1. Open Task Manager / Tasks
        if (lower.contains("task") || lower.contains("process") || lower.contains("kill app") || lower.contains("running app")) {
            return LocalAiResult(
                responseText = "⚡ **Task Manager Launched (Offline Copilot Action):**\n" +
                        "Opened **Task Manager & Process Telemetry**.\n" +
                        "- Active Windows: ${context.openWindows.size} running\n" +
                        "- CPU Load: ${context.metrics.cpuUsagePercent}% across 16 Quantum Cores\n" +
                        "- RAM Allocation: ${context.metrics.ramUsedMb} MB / ${context.metrics.ramTotalMb} MB\n" +
                        "You can monitor thread states or terminate unresponsive tasks directly.",
                action = LocalAiAction.OpenApp("task_manager", "Task Manager"),
                suggestedCommand = "tasklist"
            )
        }

        // 2. Set Wallpaper (Green Text Holy Stunner / Matrix / styles)
        if (lower.contains("wallpaper") || lower.contains("background")) {
            if (lower.contains("green") || lower.contains("stunner") || lower.contains("matrix") || lower.contains("text")) {
                return LocalAiResult(
                    responseText = "⚡ **Desktop Wallpaper Updated (Offline Action):**\n" +
                            "Applied **Green Text Holy Stunner** cyber matrix terminal theme with glowing neon typography, matrix scanlines, and quantum HUD overlays.",
                    action = LocalAiAction.SetWallpaper(0, "Green Text Holy Stunner")
                )
            } else if (lower.contains("grid") || lower.contains("slate") || lower.contains("midnight")) {
                return LocalAiResult(
                    responseText = "⚡ **Desktop Wallpaper Updated:**\nApplied **Midnight Slate Grid** geometric cyber theme.",
                    action = LocalAiAction.SetWallpaper(1, "Midnight Slate Grid")
                )
            } else if (lower.contains("neon") || lower.contains("horizon") || lower.contains("purple")) {
                return LocalAiResult(
                    responseText = "⚡ **Desktop Wallpaper Updated:**\nApplied **Neon Cyber Horizon** violet horizon theme.",
                    action = LocalAiAction.SetWallpaper(2, "Neon Cyber Horizon")
                )
            } else {
                return LocalAiResult(
                    responseText = "⚡ **Desktop Wallpaper Updated:**\nSwitched to next desktop background style.",
                    action = LocalAiAction.SetWallpaper(0, "Green Text Holy Stunner")
                )
            }
        }

        // 3. Open Compatibility Lab / Test program
        if (lower.contains("compat") || lower.contains("test program") || lower.contains("run exe") || lower.contains("pe binary") || lower.contains("win32")) {
            return LocalAiResult(
                responseText = "⚡ **PC Program Compatibility Lab Launched:**\n" +
                        "Initialized test suite for Windows 11 x86_64, WoW64 PE, POSIX Linux ELF, and Python scripts with live NTDLL & Win32 API tracing.",
                action = LocalAiAction.OpenApp("compat_lab", "PC Compatibility Lab"),
                suggestedCommand = "compat"
            )
        }

        // 4. Open Terminal / CMD
        if (lower.contains("terminal") || lower.contains("cmd") || lower.contains("command prompt") || lower.contains("console") || lower.contains("shell")) {
            return LocalAiResult(
                responseText = "⚡ **Stunner Terminal Shell Launched:**\n" +
                        "Initialized virtual command line. Try commands like `neofetch`, `matrix`, `benchmark`, `dir`, or `python script.py`.",
                action = LocalAiAction.OpenApp("terminal", "Stunner CMD"),
                suggestedCommand = "neofetch"
            )
        }

        // 5. Open VS Code Pro / Code Editor / Write Python
        if (lower.contains("code") || lower.contains("editor") || lower.contains("vs code") || lower.contains("ide")) {
            return LocalAiResult(
                responseText = "⚡ **VS Code Pro IDE Launched:**\n" +
                        "Opened code editor with syntax highlighting for Python, C/C++, HTML/JS, and Batch CMD scripts.",
                action = LocalAiAction.OpenApp("code_editor", "VS Code Pro"),
                codeSnippet = """# Holy Stunner PC Python Script
import time

def quantum_main():
    print("[HOLY STUNNER PC] Hypervisor ready.")
    print("16 Cores Synchronized @ 4.80 GHz")

quantum_main()""",
                codeLanguage = "python"
            )
        }

        // 6. Open HolyVM Hypervisor
        if (lower.contains("vm") || lower.contains("hypervisor") || lower.contains("virtual machine") || lower.contains("hardware")) {
            return LocalAiResult(
                responseText = "⚡ **HolyVM Hypervisor Launched:**\n" +
                        "Opened 16-Core virtual CPU scheduler, MMU paging inspector, and hypervisor snapshot manager.",
                action = LocalAiAction.OpenApp("vm_hypervisor", "HolyVM Hypervisor"),
                suggestedCommand = "vmm"
            )
        }

        // 7. Open File Explorer / C Drive
        if (lower.contains("file") || lower.contains("explorer") || lower.contains("folder") || lower.contains("c drive") || lower.contains("disk")) {
            return LocalAiResult(
                responseText = "⚡ **File Explorer Opened:**\n" +
                        "Displaying virtual C:\\ drive filesystem with desktop documents, binaries, and pictures.",
                action = LocalAiAction.OpenApp("file_explorer", "File Explorer"),
                suggestedCommand = "dir"
            )
        }

        // 8. Open Web Browser
        if (lower.contains("browser") || lower.contains("chrome") || lower.contains("internet") || lower.contains("web") || lower.contains("search web")) {
            return LocalAiResult(
                responseText = "⚡ **Stunner Chrome Launched:**\n" +
                        "Opened web browser with search, developer documentation, and bookmarks.",
                action = LocalAiAction.OpenApp("browser", "Stunner Chrome")
            )
        }

        // 9. Open Paint Studio
        if (lower.contains("paint") || lower.contains("draw") || lower.contains("art") || lower.contains("canvas")) {
            return LocalAiResult(
                responseText = "⚡ **Paint Studio Launched:**\n" +
                        "Opened digital painting and graphics design canvas.",
                action = LocalAiAction.OpenApp("paint", "Paint Studio")
            )
        }

        // 10. Open Calculator / Math
        if (lower.contains("calculator") || lower.contains("calc")) {
            return LocalAiResult(
                responseText = "⚡ **PC Calculator Opened:**\n" +
                        "Opened scientific & programmer hex calculator.",
                action = LocalAiAction.OpenApp("calculator", "PC Calculator")
            )
        }

        // 11. Open Settings
        if (lower.contains("setting") || lower.contains("config") || lower.contains("preference") || lower.contains("volume")) {
            return LocalAiResult(
                responseText = "⚡ **PC Settings Opened:**\n" +
                        "Configure system preferences, wallpapers, audio synthesizers, and performance modes.",
                action = LocalAiAction.OpenApp("settings", "PC Settings")
            )
        }

        // 12. Open Software Hub / App Installer
        if (lower.contains("install") || lower.contains("software hub") || lower.contains("app store") || lower.contains("store") || lower.contains("market")) {
            return LocalAiResult(
                responseText = "⚡ **Software Hub Opened:**\n" +
                        "Browse, install, and manage emulated PC applications and virtual binaries.",
                action = LocalAiAction.OpenApp("app_installer", "Software Hub")
            )
        }

        // 13. Open Games (Minesweeper / Space Invaders)
        if (lower.contains("minesweeper") || lower.contains("mine")) {
            return LocalAiResult(
                responseText = "⚡ **Minesweeper 3D Launched:**\nOpened classic PC logic puzzle.",
                action = LocalAiAction.OpenApp("minesweeper", "Minesweeper 3D")
            )
        }
        if (lower.contains("space") || lower.contains("invader") || lower.contains("arcade") || lower.contains("game")) {
            return LocalAiResult(
                responseText = "⚡ **Cyber Invaders Arcade Launched:**\nDefend Holy Stunner PC from alien bytecode incursions!",
                action = LocalAiAction.OpenApp("space_invaders", "Cyber Invaders")
            )
        }

        // 14. Media Player
        if (lower.contains("music") || lower.contains("media") || lower.contains("vlc") || lower.contains("player") || lower.contains("audio")) {
            return LocalAiResult(
                responseText = "⚡ **Cyber VLC Media Player Launched:**\nSynthesizer audio player ready.",
                action = LocalAiAction.OpenApp("media_player", "Cyber VLC")
            )
        }

        // 15. Optimize RAM & Memory
        if (lower.contains("clean ram") || lower.contains("optimize memory") || lower.contains("free ram") || lower.contains("clean memory") || lower.contains("speed up")) {
            return LocalAiResult(
                responseText = "⚡ **Virtual Memory Optimized (Offline Action):**\n" +
                        "- Cleaned 1.8 GB dormant hypervisor page tables\n" +
                        "- Trimmed virtual pagecache working set\n" +
                        "- Flushed Ring 3 heap allocations\n" +
                        "Available RAM: ${(context.metrics.ramTotalMb - context.metrics.ramUsedMb)} MB DDR5 remaining.",
                action = LocalAiAction.OptimizeRam
            )
        }

        // 16. Reboot PC / VM
        if (lower.contains("reboot") || lower.contains("restart pc") || lower.contains("restart vm") || lower.contains("power cycle")) {
            return LocalAiResult(
                responseText = "⚡ **Rebooting Holy Stunner Hypervisor...**\nInitiating safe kernel reboot sequence.",
                action = LocalAiAction.RebootPc
            )
        }

        // 17. Show Desktop / Minimize
        if (lower.contains("show desktop") || lower.contains("minimize all") || lower.contains("hide windows")) {
            return LocalAiResult(
                responseText = "⚡ **Showing Desktop:**\nMinimized all open GUI windows.",
                action = LocalAiAction.MinimizeAllWindows
            )
        }

        // 18. Quick Math / Arithmetic Calculations (e.g. 50 * 20, 1024 / 8, 25 + 75)
        val mathRegex = "^(?:calculate|what is|calc)?\\s*([0-9]+(?:\\.[0-9]+)?)\\s*([+\\-*/%^])\\s*([0-9]+(?:\\.[0-9]+)?)\\s*$".toRegex()
        val match = mathRegex.find(lower.replace("?", "").trim())
        if (match != null) {
            val a = match.groups[1]?.value?.toDoubleOrNull() ?: 0.0
            val op = match.groups[2]?.value ?: "+"
            val b = match.groups[3]?.value?.toDoubleOrNull() ?: 0.0
            val ans = when (op) {
                "+" -> a + b
                "-" -> a - b
                "*" -> a * b
                "/" -> if (b != 0.0) a / b else Double.NaN
                "%" -> a % b
                "^" -> Math.pow(a, b)
                else -> 0.0
            }
            return LocalAiResult(
                responseText = "⚡ **Offline Calculation:**\n`$a $op $b = $ans`",
                suggestedCommand = "calc $a $op $b"
            )
        }

        // 19. Python / Script Generation Request
        if (lower.contains("python") || lower.contains("script") || lower.contains("write code") || lower.contains("matrix code")) {
            return LocalAiResult(
                responseText = "⚡ **Generated Python Script for Holy Stunner PC (Offline Engine):**\n" +
                        "Here is a high-performance quantum telemetry script:",
                codeSnippet = """# Holy Stunner PC - Offline Python Routine
import time
import math

def run_telemetry():
    print("[HOLY STUNNER PC] Initializing 16-Core Quantum Engine...")
    for core in range(16):
        speed = 4.80 + (core % 4) * 0.05
        print(f"Core #{core:02d} Online -> Frequency: {speed:.2f} GHz [STABLE]")
        time.sleep(0.03)
    print("STATUS: All Hypervisor Subsystems Operational!")

if __name__ == '__main__':
    run_telemetry()""",
                codeLanguage = "python",
                suggestedCommand = "python script.py"
            )
        }

        // 20. General PC Specs & Diagnostics
        if (lower.contains("spec") || lower.contains("cpu") || lower.contains("ram") || lower.contains("diagnostic") || lower.contains("who are you")) {
            return LocalAiResult(
                responseText = "⚡ **Holy Stunner AI (Offline Hypervisor Copilot):**\n" +
                        "- **Host OS:** Holy Stunner PC Enterprise Edition (v2026.4)\n" +
                        "- **Hypervisor:** ${context.vmState.hypervisorName} [${context.vmState.status}]\n" +
                        "- **Processor:** 16-Core Quantum Stunner @ 4.80 GHz (${context.metrics.cpuUsagePercent}% load)\n" +
                        "- **Memory:** ${context.metrics.ramUsedMb} MB / ${context.metrics.ramTotalMb} MB DDR5\n" +
                        "- **Active User:** ${context.userProfile.displayName} (${context.userProfile.email})\n" +
                        "- **Active Windows:** ${context.openWindows.size} open\n" +
                        "I am fully operational offline to open tasks, manage processes, execute terminal commands, change wallpapers, and generate code!",
                suggestedCommand = "neofetch"
            )
        }

        // Default offline response
        return LocalAiResult(
            responseText = "⚡ **Holy Stunner AI Copilot (Offline Mode):**\n" +
                    "I received your request: \"$prompt\".\n" +
                    "I can perform offline tasks for you on Holy Stunner PC:\n" +
                    "• **Open Tasks**: Say *'open task manager'*, *'open terminal'*, or *'open code editor'*\n" +
                    "• **Set Wallpaper**: Say *'set green wallpaper'* or *'set wallpaper to green text holy stunner'*\n" +
                    "• **Test Programs**: Say *'open compat lab'* to run Windows PE binaries\n" +
                    "• **Optimize**: Say *'clean ram'* or *'reboot pc'*",
            suggestedCommand = "help"
        )
    }
}
