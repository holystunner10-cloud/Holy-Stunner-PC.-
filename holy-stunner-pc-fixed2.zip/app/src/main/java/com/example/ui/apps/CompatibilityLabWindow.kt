package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Rule
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CompatibilityMode
import com.example.model.ProgramTestReport
import com.example.model.VirtualMachineState
import com.example.service.CompatibilityLayerService
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SleekAiGradientEnd
import com.example.ui.theme.SleekAiGradientStart
import com.example.ui.theme.SleekBorder
import com.example.ui.theme.SleekBorderSubtle
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.SleekSurfaceContainer
import com.example.ui.theme.SleekSurfaceDark
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WindowSurfaceDark
import kotlinx.coroutines.launch

@Composable
fun CompatibilityLabWindow(
    vmState: VirtualMachineState,
    initialSnippet: String? = null,
    onOpenInEditor: (String, String) -> Unit = { _, _ -> },
    onSaveToDesktop: (String, String) -> Unit = { _, _ -> }
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedMode by remember { mutableStateOf(CompatibilityMode.WINDOWS_11_X64) }
    var programName by remember { mutableStateOf("demo_app.exe") }
    var programSource by remember {
        mutableStateOf(
            initialSnippet ?: """// Holy Stunner Win32 C/C++ Test Program
#include <windows.h>
#include <stdio.h>

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    printf("=== HOLY STUNNER PC COMPATIBILITY SUITE ===\n");
    printf("Initializing virtual PE subsystem...\n");
    
    HANDLE hFile = CreateFileW(L"C:\\Users\\HolyStunner\\app_data.dat", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile != INVALID_HANDLE_VALUE) {
        printf("Win32 File Stream: OPENED [HANDLE 0x4C]\n");
        printf("DirectX 12 Shader Pipeline: SYNCHRONIZED\n");
        CloseHandle(hFile);
    }
    
    printf("Execution Status: 100% SUCCESS (0 leaks detected)\n");
    return 0;
}"""
        )
    }

    var isRunning by remember { mutableStateOf(false) }
    var testReport by remember { mutableStateOf<ProgramTestReport?>(null) }
    val coroutineScope = rememberCoroutineScope()

    val samplePrograms = listOf(
        "Win32 Direct3D Demo" to (CompatibilityMode.WINDOWS_11_X64 to """// Direct3D 12 Win32 Application
#include <windows.h>
#include <d3d12.h>
#include <stdio.h>

int main() {
    printf("[WIN32] Initializing DirectX 12 Device on Holy Stunner GPU...\n");
    printf("[WIN32] Framebuffer: 1920x1080 @ 120Hz (Vulkan Translation Layer)\n");
    printf("[WIN32] Allocated 32MB Vertex & Index Buffers\n");
    printf("[WIN32] Shaders compiled with zero translation stalls!\n");
    return 0;
}"""),
        "Python Data Pipeline" to (CompatibilityMode.PYTHON_INTERPRETER to """# Python Data Processing Script
import time
import math

print("=== HOLY STUNNER PYTHON 3.12 PIPELINE ===")
for i in range(1, 6):
    throughput = math.sqrt(i * 1024) * 12.5
    print(f"Batch #{i}: Processed {throughput:.1f} records/sec [OK]")
    time.sleep(0.05)
print("Pipeline Finished: All data committed to C:\\ drive.")"""),
        "POSIX ELF Micro-Server" to (CompatibilityMode.POSIX_LINUX to """// POSIX Linux Server Routine
#include <stdio.h>
#include <unistd.h>

int main() {
    printf("[POSIX] Starting socket listener on 127.0.0.1:8080...\n");
    printf("[POSIX] Virtual NIC: eth0 linked at 10 Gbps\n");
    printf("[POSIX] Handling 1,000 simulated HTTP requests...\n");
    printf("[POSIX] Average response latency: 0.12ms\n");
    return 0;
}"""),
        "Batch System Check" to (CompatibilityMode.BATCH_CMD_ENGINE to """@echo off
echo ========================================
echo HOLY STUNNER COMPATIBILITY TEST SCRIPT
echo ========================================
echo OS: Windows 11 Enterprise Edition (x64)
echo CPU: 16-Core Virtual Quantum Hyper-V
echo RAM: 16 GB DDR5 6400MHz
echo Status: ALL WIN32 SUBSYSTEMS GREEN.""")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WindowSurfaceDark)
            .padding(10.dp)
    ) {
        // Lab Header with Status
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF0F172A), Color(0xFF1E1B4B))))
                .border(1.dp, SleekBorderSubtle, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Brush.linearGradient(listOf(SleekAiGradientStart, SleekAiGradientEnd))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Tune, contentDescription = "Lab", tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Column {
                    Text("PC Compatibility & Program Test Lab", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("Multi-Architecture Execution & Win32 API Emulation Engine", color = SleekPrimary, fontSize = 10.sp)
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF064E3B))
                    .border(1.dp, TerminalGreen.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text("JIT Recompiler: Active", color = TerminalGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tabs
        val tabs = listOf("Program Runner & Sandbox", "CPU Registers & MMU", "Win32 API Trace", "User Testing Guidance")
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF0F172A),
            contentColor = SleekPrimary,
            edgePadding = 0.dp,
            indicator = { tabPositions ->
                if (selectedTab < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = SleekPrimary,
                        height = 2.dp
                    )
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, SleekBorderSubtle, RoundedCornerShape(8.dp))
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) SleekPrimary else TextSecondary
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tab Content
        when (selectedTab) {
            0 -> {
                // Tab 0: Program Runner & Sandbox
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Quick Samples Selector
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        samplePrograms.forEach { (name, pair) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF1E293B))
                                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
                                    .clickable {
                                        selectedMode = pair.first
                                        programSource = pair.second
                                        programName = when (pair.first) {
                                            CompatibilityMode.PYTHON_INTERPRETER -> "pipeline.py"
                                            CompatibilityMode.POSIX_LINUX -> "server.elf"
                                            CompatibilityMode.BATCH_CMD_ENGINE -> "check.bat"
                                            else -> "app.exe"
                                        }
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(text = name, color = TextPrimary, fontSize = 10.sp)
                            }
                        }
                    }

                    // Mode Selection & Program Name Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Compatibility Mode dropdown pills
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CompatibilityMode.values().forEach { mode ->
                                val isSelected = selectedMode == mode
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) SleekPrimary else Color(0xFF1E293B))
                                        .border(1.dp, if (isSelected) SleekPrimary else Color(0xFF334155), RoundedCornerShape(6.dp))
                                        .clickable { selectedMode = mode }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = mode.tag,
                                        color = if (isSelected) Color.Black else TextPrimary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // Run / Test Button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Brush.linearGradient(listOf(TerminalGreen, Color(0xFF059669))))
                                .clickable(enabled = !isRunning) {
                                    isRunning = true
                                    coroutineScope.launch {
                                        testReport = CompatibilityLayerService.executeProgramInVm(
                                            name = programName,
                                            sourceCodeOrPayload = programSource,
                                            mode = selectedMode
                                        )
                                        isRunning = false
                                    }
                                }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                                .testTag("compat_lab_run_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                if (isRunning) {
                                    CircularProgressIndicator(modifier = Modifier.size(12.dp), color = Color.Black, strokeWidth = 2.dp)
                                } else {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Run", tint = Color.Black, modifier = Modifier.size(16.dp))
                                }
                                Text("EXECUTE IN VM", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Source Code Editor & Output (Split Pane)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Source Code Input Box
                        Column(
                            modifier = Modifier
                                .weight(1.2f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF090D16))
                                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "PROGRAM SOURCE / PAYLOAD ($programName)",
                                color = TextSecondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            BasicTextField(
                                value = programSource,
                                onValueChange = { programSource = it },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState()),
                                textStyle = TextStyle(
                                    color = Color(0xFFE2E8F0),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp
                                ),
                                cursorBrush = SolidColor(SleekPrimary)
                            )
                        }

                        // Execution Output & Telemetry Box
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF050811))
                                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "EMULATION OUTPUT & TELEMETRY",
                                color = TextSecondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))

                            if (testReport != null) {
                                LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    item {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(Color(0xFF0F172A))
                                                .padding(6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Time: ${testReport?.executionTimeMs}ms", color = SleekPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                            Text("RAM: ${testReport?.peakMemoryKb} KB", color = ElectricViolet, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                            Text("Exit: ${testReport?.exitCode}", color = TerminalGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        }
                                    }

                                    item {
                                        Text(
                                            text = testReport!!.stdout,
                                            color = TerminalGreen,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            lineHeight = 15.sp
                                        )
                                    }

                                    items(testReport!!.optimizationNotes) { note ->
                                        Text(note, color = Color(0xFFA5F3FC), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            } else {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text("Click 'EXECUTE IN VM' to test program compatibility.", color = TextMuted, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // Tab 1: CPU Registers & MMU
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Virtual CPU 64-bit Core Registers (x86_64 / AMD64)", color = SleekPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                                val regList = listOf(
                                    "RAX" to vmState.registers.rax,
                                    "RBX" to vmState.registers.rbx,
                                    "RCX" to vmState.registers.rcx,
                                    "RDX" to vmState.registers.rdx,
                                    "RSI" to vmState.registers.rsi,
                                    "RDI" to vmState.registers.rdi,
                                    "RSP" to vmState.registers.rsp,
                                    "RBP" to vmState.registers.rbp,
                                    "RIP" to vmState.registers.rip
                                )

                                regList.chunked(3).forEach { rowRegs ->
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        rowRegs.forEach { (name, value) ->
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(Color(0xFF1E293B))
                                                    .padding(6.dp)
                                            ) {
                                                Column {
                                                    Text(name, color = SleekPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                                    Text(value, color = TextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                                }
                                            }
                                        }
                                    }
                                }

                                Text("EFLAGS: ${vmState.registers.flags}", color = TerminalGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Virtual MMU Paged Memory Map", color = ElectricViolet, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                                vmState.memoryPages.forEach { page ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFF1E293B))
                                            .padding(6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(page.address, color = SleekPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                        Text(page.type, color = TextPrimary, fontSize = 9.sp)
                                        Text("${page.sizeKb} KB", color = TextSecondary, fontSize = 9.sp)
                                        Text(page.protection, color = TerminalGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // Tab 2: Win32 API Call Trace
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                ) {
                    Text(
                        text = "REAL-TIME WIN32 / NTDLL SYSTEM CALL TRACE LOG",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF050811))
                            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val traces = testReport?.apiTraces ?: listOf(
                            com.example.model.Win32ApiTrace(System.currentTimeMillis(), "NtQuerySystemInformation", "SystemInformationClass: 5", "STATUS_SUCCESS"),
                            com.example.model.Win32ApiTrace(System.currentTimeMillis() + 2, "LdrLoadDll", "PathToFile: \"C:\\Windows\\System32\\user32.dll\"", "0x00007FFA_C1000000"),
                            com.example.model.Win32ApiTrace(System.currentTimeMillis() + 5, "VirtualAlloc", "BaseAddress: NULL, Size: 65536, AllocationType: MEM_COMMIT", "0x000001D4_2C800000"),
                            com.example.model.Win32ApiTrace(System.currentTimeMillis() + 10, "CreateThread", "lpStartAddress: 0x00007FF6_B4A01020, lpParameter: NULL", "HANDLE 0x00000054")
                        )

                        items(traces) { trace ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF0F172A))
                                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(4.dp))
                                    .padding(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(trace.functionName, color = SleekPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    Text(trace.returnValue, color = TerminalGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                                Text("Params: ${trace.parameters}", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            3 -> {
                // Tab 3: User Testing Guidance & Tutorials
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.HelpOutline, contentDescription = "Guide", tint = SleekPrimary, modifier = Modifier.size(20.dp))
                                    Text("How to Test Your PC Programs on Holy Stunner PC", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(
                                    "Holy Stunner PC provides a full high-performance virtualization and compatibility layer capable of executing standard PC binaries and scripts directly inside Android.",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    val guideSteps = listOf(
                        Triple("1. Choose Target Architecture & Subsystem", "Select whether your code is a modern 64-bit Windows PE binary (Win11 x64), 32-bit WoW64 legacy application, POSIX Linux ELF executable, or Python / Batch script.", Icons.Default.Tune),
                        Triple("2. Paste Source or Import from Virtual C: Drive", "You can write C, C++, Python, Batch, or x86 assembly directly into the Sandbox editor, or load files created in VS Code Pro and File Explorer.", Icons.Default.Code),
                        Triple("3. Execute & Monitor Real-Time VM Telemetry", "Click 'EXECUTE IN VM'. The JIT recompiler translates x86 instructions to ARM64 micro-ops while logging memory allocations, cycle count, and stdout.", Icons.Default.PlayArrow),
                        Triple("4. Inspect Win32 API Calls & CPU Registers", "Switch to the 'CPU Registers' and 'Win32 API Trace' tabs to verify that system calls (`VirtualAlloc`, `CreateFileW`, Direct3D pipelines) are operating cleanly without memory leaks.", Icons.Default.BugReport),
                        Triple("5. Package into .EXE for Software Hub", "Once verified, save your program directly to the Desktop or package it for 1-click execution in the Software Hub marketplace.", Icons.Default.CheckCircle)
                    )

                    items(guideSteps) { (title, desc, icon) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0F172A))
                                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SleekSurfaceContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(icon, contentDescription = title, tint = SleekPrimary, modifier = Modifier.size(18.dp))
                            }

                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(title, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(desc, color = TextSecondary, fontSize = 10.sp, lineHeight = 14.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
