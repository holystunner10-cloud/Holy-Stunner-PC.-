package com.example.ui.apps

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberPink
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.WindowSurfaceDark
import kotlinx.coroutines.delay
import kotlin.random.Random

data class Invader(var x: Float, var y: Float, var isAlive: Boolean = true)
data class Bullet(var x: Float, var y: Float)

@Composable
fun SpaceInvadersWindow() {
    var playerX by remember { mutableFloatStateOf(150f) }
    var score by remember { mutableIntStateOf(0) }
    var isGameOver by remember { mutableStateOf(false) }
    var isGameWon by remember { mutableStateOf(false) }

    val invaders = remember {
        mutableStateListOf<Invader>().apply {
            for (r in 0..2) {
                for (c in 0..5) {
                    add(Invader(x = 30f + c * 45f, y = 20f + r * 30f))
                }
            }
        }
    }

    val bullets = remember { mutableStateListOf<Bullet>() }

    fun restartGame() {
        playerX = 150f
        score = 0
        isGameOver = false
        isGameWon = false
        bullets.clear()
        invaders.clear()
        for (r in 0..2) {
            for (c in 0..5) {
                invaders.add(Invader(x = 30f + c * 45f, y = 20f + r * 30f))
            }
        }
    }

    LaunchedEffect(isGameOver, isGameWon) {
        var invaderDir = 1f
        while (!isGameOver && !isGameWon) {
            delay(50)

            // Move bullets
            val bulletsToRemove = mutableListOf<Bullet>()
            bullets.forEach { b ->
                b.y -= 10f
                if (b.y < 0) bulletsToRemove.add(b)

                // Hit check
                invaders.forEach { inv ->
                    if (inv.isAlive && b.x in (inv.x - 15f)..(inv.x + 25f) && b.y in (inv.y - 10f)..(inv.y + 20f)) {
                        inv.isAlive = false
                        bulletsToRemove.add(b)
                        score += 100
                    }
                }
            }
            bullets.removeAll(bulletsToRemove)

            // Move invaders
            var shouldReverse = false
            invaders.forEach { inv ->
                if (inv.isAlive) {
                    inv.x += invaderDir * 2f
                    if (inv.x > 280f || inv.x < 10f) {
                        shouldReverse = true
                    }
                    if (inv.y >= 220f) {
                        isGameOver = true
                    }
                }
            }
            if (shouldReverse) {
                invaderDir *= -1f
                invaders.forEach { if (it.isAlive) it.y += 10f }
            }

            if (invaders.none { it.isAlive }) {
                isGameWon = true
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WindowSurfaceDark)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Score Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0F172A))
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("SCORE: $score", color = NeonCyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(if (isGameWon) "VICTORY!" else if (isGameOver) "GAME OVER" else "HOLY DEFENDER", color = if (isGameWon) TerminalGreen else if (isGameOver) Color(0xFFEF4444) else TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF1E293B))
                    .clickable { restartGame() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Restart", tint = NeonCyan, modifier = Modifier.size(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Game Arena Canvas
        Box(
            modifier = Modifier
                .size(310.dp, 250.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF050811))
                .border(1.dp, NeonCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Draw Invaders
                invaders.forEach { inv ->
                    if (inv.isAlive) {
                        drawRect(
                            color = CyberPink,
                            topLeft = Offset(inv.x, inv.y),
                            size = Size(20f, 14f)
                        )
                    }
                }

                // Draw Bullets
                bullets.forEach { b ->
                    drawRect(
                        color = Color.Yellow,
                        topLeft = Offset(b.x, b.y),
                        size = Size(4f, 8f)
                    )
                }

                // Draw Player
                drawRect(
                    color = NeonCyan,
                    topLeft = Offset(playerX - 12f, 230f),
                    size = Size(24f, 12f)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Mobile Game Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp, 36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1E293B))
                    .clickable { playerX = (playerX - 20f).coerceAtLeast(20f) },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Left", tint = Color.White, modifier = Modifier.size(20.dp))
            }

            Box(
                modifier = Modifier
                    .height(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(NeonCyan)
                    .clickable {
                        if (!isGameOver && !isGameWon) {
                            bullets.add(Bullet(playerX, 220f))
                        }
                    }
                    .padding(horizontal = 24.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.FlashOn, contentDescription = "Fire", tint = Color.Black, modifier = Modifier.size(16.dp))
                    Text("FIRE", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Box(
                modifier = Modifier
                    .size(50.dp, 36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1E293B))
                    .clickable { playerX = (playerX + 20f).coerceAtMost(290f) },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.ArrowForward, contentDescription = "Right", tint = Color.White, modifier = Modifier.size(20.dp))
            }
        }
    }
}
