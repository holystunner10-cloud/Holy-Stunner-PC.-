package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FileType
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WindowSurfaceDark
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun CodeEditorWindow(
    initialCode: String? = null,
    initialLanguage: String? = null,
    onSaveFile: (String, String, FileType) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()

    var codeText by remember {
        mutableStateOf(
            initialCode ?: """# Holy Stunner PC Python Runtime v3.12
import time
import math

def calculate_quantum_metrics():
    print("=== HOLY STUNNER QUANTUM ENGINE ===")
    for step in range(1, 6):
        flux = math.sin(step * 0.5) * 100
        print(f"Node [{step}]: Quantum flux at {flux:.2f} THz - STABLE")
        time.sleep(0.1)
    print("\nResult: System optimal, 0 memory leaks detected!")

calculate_quantum_metrics()"""
        )
    }

    var selectedLang by remember { mutableStateOf(initialLanguage ?: "Python") }
    var fileName by remember { mutableStateOf("script.py") }
    var consoleOutput by remember { mutableStateOf("Ready to execute code. Click 'RUN' above.") }
    var isRunning by remember { mutableStateOf(false) }

    val templates = listOf(
        "Quantum Metrics" to """# Quantum Metrics Script
import time

print("HOLY STUNNER PC: Running benchmark...")
for i in range(1, 6):
    print(f"Core #{i} throughput: 4.80 GHz [ACTIVE]")
print("Done! Overall Score: 99.8%")""",
        "Matrix Rain" to """# Matrix Rain Simulator
chars = "010110010101"
print("[MATRIX STREAM INITIALIZED]")
for i in range(8):
    print(f"Row {i}: {chars * 3}")
print("[STREAM COMPLETED]")""",
        "Batch Diagnostic" to """@echo off
echo ===============================
echo HOLY STUNNER SYSTEM DIAGNOSTIC
echo ===============================
echo CPU: Quantum Neural 16-Core
echo RAM: 16 GB Ultra DDR5
echo GPU: RTX Quantum Stunner
echo All services ONLINE."""
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WindowSurfaceDark)
            .padding(10.dp)
    ) {
        // Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0F172A))
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Code, contentDescription = "IDE", tint = NeonCyan, modifier = Modifier.size(18.dp))
                Text(
                    text = "VS Code Pro • $fileName",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                // Save Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF1E293B))
                        .clickable {
                            val type = if (fileName.endsWith(".py")) FileType.PYTHON else if (fileName.endsWith(".bat")) FileType.BATCH else FileType.TEXT
                            onSaveFile(fileName, codeText, type)
                            consoleOutput = "File '$fileName' successfully saved to Desktop."
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Save, contentDescription = "Save", tint = NeonCyan, modifier = Modifier.size(13.dp))
                        Text("Save", color = TextPrimary, fontSize = 11.sp)
                    }
                }

                // Run Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(TerminalGreen)
                        .clickable(enabled = !isRunning) {
                            isRunning = true
                            consoleOutput = "Compiling & executing $fileName..."
                            coroutineScope.launch {
                                delay(600)
                                isRunning = false
                                consoleOutput = "[STDOUT] Stunner Virtual Interpreter v3.12\n" +
                                        "[PROCESS STARTED] PID: 4092\n" +
                                        "----------------------------------------\n" +
                                        codeText.lines().filter { it.contains("print") || it.contains("echo") }
                                            .joinToString("\n") { line ->
                                                val content = line.substringAfter("(").substringBeforeLast(")")
                                                    .replace("\"", "").replace("'", "")
                                                    .replace("echo ", "")
                                                "[OUT] $content"
                                            }.ifBlank { "[OUT] Script executed with exit code 0 (Success)." } +
                                        "\n----------------------------------------\n" +
                                        "[PROCESS TERMINATED] Execution time: 0.038s"
                            }
                        }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .testTag("code_run_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (isRunning) {
                            CircularProgressIndicator(modifier = Modifier.size(12.dp), color = Color.Black, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Run", tint = Color.Black, modifier = Modifier.size(14.dp))
                        }
                        Text("RUN", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Template selector chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            templates.forEach { (name, snippet) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF1E293B))
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
                        .clickable {
                            codeText = snippet
                            fileName = if ("Batch" in name) "diagnostics.bat" else "script.py"
                        }
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(text = name, color = TextSecondary, fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Code Editor Viewport with Line Numbers
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF090D16))
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                .padding(8.dp)
        ) {
            // Line numbers column
            val lineCount = codeText.lines().size.coerceAtLeast(1)
            Column(
                modifier = Modifier
                    .width(28.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.End
            ) {
                for (i in 1..lineCount) {
                    Text(
                        text = "$i",
                        color = Color(0xFF475569),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Code text field
            BasicTextField(
                value = codeText,
                onValueChange = { codeText = it },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .testTag("code_editor_textarea"),
                textStyle = TextStyle(
                    color = Color(0xFFE2E8F0),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                ),
                cursorBrush = SolidColor(NeonCyan)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Console Output Panel
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFF050811))
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(6.dp))
                .padding(6.dp)
        ) {
            Text(
                text = "TERMINAL CONSOLE OUTPUT",
                color = TextSecondary,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = consoleOutput,
                color = TerminalGreen,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 14.sp,
                modifier = Modifier.verticalScroll(rememberScrollState())
            )
        }
    }
}
