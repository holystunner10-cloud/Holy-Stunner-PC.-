package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HolyAiMessage
import com.example.model.Sender
import com.example.model.SystemMetrics
import com.example.model.UserProfile
import com.example.model.VirtualMachineState
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SleekAiGradientEnd
import com.example.ui.theme.SleekAiGradientStart
import com.example.ui.theme.SleekBorderSubtle
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WindowSurfaceDark

@Composable
fun HolyAiWindow(
    messages: List<HolyAiMessage>,
    isThinking: Boolean,
    userProfile: UserProfile = UserProfile(),
    vmState: VirtualMachineState = VirtualMachineState(),
    systemMetrics: SystemMetrics = SystemMetrics(),
    onSendMessage: (String) -> Unit,
    onExecuteCommand: (String) -> Unit,
    onOpenCodeInEditor: (String, String) -> Unit,
    onOpenCompatLab: (String) -> Unit = {},
    onOpenApp: (String) -> Unit = {}
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val clipboardManager = LocalClipboardManager.current

    LaunchedEffect(messages.size, isThinking) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val quickActions = listOf(
        "⚡ Check PC System Telemetry" to "Check PC hardware, CPU, and VM diagnostics",
        "🧪 Test Program in Compat Lab" to "Open Compatibility Lab to run PC binaries",
        "🐍 Generate Python Matrix Script" to "Write a Python script for Holy Stunner PC",
        "🌐 Launch Stunner Web Browser" to "Open web browser for browsing",
        "🚀 Optimize VM Memory & RAM" to "Clean RAM and optimize hypervisor caches",
        "💻 Open Stunner Terminal" to "Launch command terminal"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WindowSurfaceDark)
            .padding(10.dp)
    ) {
        // AI & PC Environment Telemetry Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF0F172A), Color(0xFF1E1B4B))))
                .border(1.dp, SleekBorderSubtle, RoundedCornerShape(10.dp))
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(SleekAiGradientStart, SleekAiGradientEnd))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "AI", tint = Color.White, modifier = Modifier.size(20.dp))
                    }

                    Column {
                        Text("Holy Stunner AI Copilot", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (isThinking) "Neural Coprocessor: Synthesizing..." else "Connected to Emulated PC Environment",
                            color = if (isThinking) SleekPrimary else TerminalGreen,
                            fontSize = 10.sp
                        )
                    }
                }

                // Google User Authenticated Badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1E293B))
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.AccountCircle, contentDescription = "User", tint = SleekPrimary, modifier = Modifier.size(14.dp))
                    Text(userProfile.displayName, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                }
            }

            // Live PC Telemetry Micro-Pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF090D16))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("CPU: ${systemMetrics.cpuUsagePercent}% (16-Core)", color = SleekPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF090D16))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("RAM: ${(systemMetrics.ramUsedGb * 10).toInt() / 10f} / ${systemMetrics.ramTotalGb} GB", color = ElectricViolet, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF090D16))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("VDisk C:\\: ${systemMetrics.storageUsedGb.toInt()} GB", color = TerminalGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF090D16))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("Hypervisor: Active", color = Color(0xFFA5F3FC), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Messages list
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                AiMessageBubble(
                    message = msg,
                    onExecuteCommand = onExecuteCommand,
                    onOpenCodeInEditor = onOpenCodeInEditor,
                    onOpenCompatLab = onOpenCompatLab,
                    onCopy = { clipboardManager.setText(AnnotatedString(it)) }
                )
            }

            if (isThinking) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = SleekPrimary, strokeWidth = 2.dp)
                        Text(
                            text = "Holy Stunner AI is executing neural reasoning with PC environment...",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Quick action chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickActions.forEach { (label, prompt) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1E293B))
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
                        .clickable { onSendMessage(prompt) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(text = label, color = TextPrimary, fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Input row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Command Holy AI or query virtual PC state...", fontSize = 12.sp, color = TextSecondary) },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("holy_ai_input"),
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SleekPrimary,
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedContainerColor = Color(0xFF0F172A),
                    unfocusedContainerColor = Color(0xFF0F172A),
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        onSendMessage(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Brush.linearGradient(listOf(SleekAiGradientStart, SleekAiGradientEnd)))
                    .testTag("holy_ai_send_button")
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun AiMessageBubble(
    message: HolyAiMessage,
    onExecuteCommand: (String) -> Unit,
    onOpenCodeInEditor: (String, String) -> Unit,
    onOpenCompatLab: (String) -> Unit,
    onCopy: (String) -> Unit
) {
    val isUser = message.sender == Sender.USER

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(
                    width = 1.dp,
                    color = if (isUser) SleekPrimary.copy(alpha = 0.5f) else SleekBorderSubtle,
                    shape = RoundedCornerShape(12.dp)
                ),
            color = if (isUser) Color(0xFF0C4A6E) else Color(0xFF1E293B),
            tonalElevation = 2.dp
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = message.text,
                    color = TextPrimary,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )

                // Render code snippet if present
                if (!message.codeSnippet.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF090D16))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = (message.codeLanguage ?: "code").uppercase(),
                                color = SleekPrimary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF1E293B))
                                        .clickable { onCopy(message.codeSnippet) }
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("Copy", color = TextSecondary, fontSize = 9.sp)
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF0369A1))
                                        .clickable { onOpenCodeInEditor(message.codeSnippet, message.codeLanguage ?: "python") }
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("Open IDE", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF065F46))
                                        .clickable { onOpenCompatLab(message.codeSnippet) }
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("Test in VM", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = message.codeSnippet,
                            color = Color(0xFFA5F3FC),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                }

                // Suggested command execution button
                if (!message.suggestedCommand.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF064E3B))
                            .border(1.dp, TerminalGreen, RoundedCornerShape(6.dp))
                            .clickable { onExecuteCommand(message.suggestedCommand) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Terminal, contentDescription = "Run", tint = TerminalGreen, modifier = Modifier.size(13.dp))
                            Text(
                                text = "Execute in VM: '${message.suggestedCommand}'",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
