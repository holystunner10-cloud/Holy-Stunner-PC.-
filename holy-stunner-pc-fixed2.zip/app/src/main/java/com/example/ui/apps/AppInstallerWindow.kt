package com.example.ui.apps

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SettingsApplications
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppCategory
import com.example.model.PcApp
import com.example.ui.components.getPcIcon
import com.example.ui.theme.SleekBorder
import com.example.ui.theme.SleekBorderSubtle
import com.example.ui.theme.SleekOnPrimary
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.SleekPrimaryContainer
import com.example.ui.theme.SleekSecondary
import com.example.ui.theme.SleekSurfaceContainer
import com.example.ui.theme.SleekSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WindowSurfaceDark

@Composable
fun AppInstallerWindow(
    apps: List<PcApp>,
    onInstallApp: (String) -> Unit,
    onUninstallApp: (String) -> Unit,
    onLaunchApp: (String) -> Unit,
    onCreateCustomApp: (String, String, AppCategory) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<AppCategory?>(null) }

    // Custom .EXE Wizard State
    var customExeName by remember { mutableStateOf("") }
    var customExeDesc by remember { mutableStateOf("") }
    var customExeCategory by remember { mutableStateOf(AppCategory.PRODUCTIVITY) }
    var isInstallingCustom by remember { mutableStateOf(false) }
    var customInstallProgress by remember { mutableStateOf(0f) }

    val tabs = listOf("Software Catalog", "Custom .EXE Installer")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SleekSurfaceDark)
            .padding(14.dp)
    ) {
        // Top Navigation Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = SleekSurfaceContainer,
            contentColor = SleekPrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = SleekPrimary,
                    height = 2.dp
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, SleekBorderSubtle, RoundedCornerShape(12.dp))
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) SleekPrimary else TextSecondary
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (selectedTab == 0) {
            // Software Hub Catalog View
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search PC applications & utilities...", fontSize = 12.sp, color = TextMuted) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = SleekSecondary, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("installer_search"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SleekPrimary,
                        unfocusedBorderColor = SleekBorderSubtle,
                        focusedContainerColor = SleekSurfaceContainer,
                        unfocusedContainerColor = SleekSurfaceContainer,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Category Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    CategoryChip(
                        label = "All Packages",
                        isSelected = selectedCategory == null,
                        onClick = { selectedCategory = null }
                    )
                }
                items(AppCategory.values().toList()) { cat ->
                    CategoryChip(
                        label = cat.title,
                        isSelected = selectedCategory == cat,
                        onClick = { selectedCategory = cat }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            val filteredApps = apps.filter { app ->
                val matchesQuery = searchQuery.isBlank() ||
                        app.name.contains(searchQuery, ignoreCase = true) ||
                        app.description.contains(searchQuery, ignoreCase = true)
                val matchesCategory = selectedCategory == null || app.category == selectedCategory
                matchesQuery && matchesCategory
            }

            // Apps List
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredApps) { app ->
                    AppCatalogCard(
                        app = app,
                        onInstall = { onInstallApp(app.id) },
                        onUninstall = { onUninstallApp(app.id) },
                        onLaunch = { onLaunchApp(app.id) }
                    )
                }
            }
        } else {
            // Custom .EXE Installer Wizard View
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(SleekSurfaceContainer)
                    .border(1.dp, SleekBorderSubtle, RoundedCornerShape(16.dp))
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Default.SettingsApplications, contentDescription = "Installer", tint = SleekPrimary, modifier = Modifier.size(24.dp))
                    Column {
                        Text(text = "Holy Stunner .EXE Setup Wizard", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Install custom PC binaries, script packages & utilities into virtual C:\\ drive", color = TextSecondary, fontSize = 11.sp)
                    }
                }

                OutlinedTextField(
                    value = customExeName,
                    onValueChange = { customExeName = it },
                    label = { Text("Executable / Program Name (e.g. CyberBot.exe, StunnerIDE)", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SleekPrimary,
                        unfocusedBorderColor = SleekBorderSubtle,
                        focusedContainerColor = SleekSurfaceDark,
                        unfocusedContainerColor = SleekSurfaceDark,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                OutlinedTextField(
                    value = customExeDesc,
                    onValueChange = { customExeDesc = it },
                    label = { Text("Program Description", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SleekPrimary,
                        unfocusedBorderColor = SleekBorderSubtle,
                        focusedContainerColor = SleekSurfaceDark,
                        unfocusedContainerColor = SleekSurfaceDark,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                // Installation Path preview
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SleekSurfaceDark)
                        .border(1.dp, SleekBorderSubtle, RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = "Path", tint = SleekPrimary, modifier = Modifier.size(16.dp))
                    Text(
                        text = "Target Directory: C:\\Program Files\\${if (customExeName.isNotBlank()) customExeName else "MyProgram"}\\",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                if (isInstallingCustom) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = "Extracting virtual PC payload... ${(customInstallProgress * 100).toInt()}%", color = SleekPrimary, fontSize = 11.sp)
                        LinearProgressIndicator(
                            progress = { customInstallProgress },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = SleekPrimary,
                            trackColor = SleekSurfaceDark
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                Button(
                    onClick = {
                        if (customExeName.isNotBlank()) {
                            onCreateCustomApp(customExeName, customExeDesc.ifBlank { "Custom PC application" }, customExeCategory)
                            customExeName = ""
                            customExeDesc = ""
                            selectedTab = 0
                        }
                    },
                    enabled = customExeName.isNotBlank() && !isInstallingCustom,
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SleekPrimary, contentColor = SleekOnPrimary)
                ) {
                    Icon(Icons.Default.Download, contentDescription = "Install", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Execute .EXE Installation Wizard", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun CategoryChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) SleekPrimaryContainer else SleekSurfaceContainer)
            .border(1.dp, if (isSelected) SleekPrimary else SleekBorderSubtle, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) SleekPrimary else TextPrimary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun AppCatalogCard(
    app: PcApp,
    onInstall: () -> Unit,
    onUninstall: () -> Unit,
    onLaunch: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, SleekBorderSubtle, RoundedCornerShape(14.dp))
            .testTag("app_card_${app.id}"),
        color = SleekSurfaceContainer
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // App Icon & Metadata
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(app.accentColor).copy(alpha = 0.15f))
                            .border(1.dp, Color(app.accentColor).copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = getPcIcon(app.iconName),
                            contentDescription = app.name,
                            tint = Color(app.accentColor),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = app.name,
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "v${app.version}",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                        Text(
                            text = "${app.category.title} • ${app.sizeMb} MB",
                            color = SleekSecondary,
                            fontSize = 10.sp
                        )
                        Text(
                            text = app.description,
                            color = TextMuted,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Action Button
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (app.isInstalling) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SleekSurfaceDark)
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                CircularProgressIndicator(modifier = Modifier.size(12.dp), color = SleekPrimary, strokeWidth = 2.dp)
                                Text("Installing...", color = SleekPrimary, fontSize = 11.sp)
                            }
                        }
                    } else if (app.isInstalled) {
                        // Launch button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SleekPrimary)
                                .clickable { onLaunch() }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.Launch, contentDescription = "Open", tint = SleekOnPrimary, modifier = Modifier.size(13.dp))
                                Text("Launch", color = SleekOnPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Uninstall button (if not default)
                        if (!app.isDefault) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SleekSurfaceDark)
                                    .border(1.dp, SleekBorderSubtle, RoundedCornerShape(8.dp))
                                    .clickable { onUninstall() }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Uninstall", tint = Color(0xFFF87171), modifier = Modifier.size(13.dp))
                            }
                        }
                    } else {
                        // Install button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SleekPrimary)
                                .clickable { onInstall() }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.Download, contentDescription = "Install", tint = SleekOnPrimary, modifier = Modifier.size(13.dp))
                                Text("Install", color = SleekOnPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Install Progress Bar
            if (app.isInstalling) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { app.installProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = SleekPrimary,
                    trackColor = SleekSurfaceDark
                )
            }
        }
    }
}
