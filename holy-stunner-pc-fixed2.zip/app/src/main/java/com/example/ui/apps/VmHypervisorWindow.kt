package com.example.ui.apps

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VirtualMachineState
import com.example.model.VmStatus
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SleekAiGradientEnd
import com.example.ui.theme.SleekAiGradientStart
import com.example.ui.theme.SleekBorderSubtle
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.SleekSurfaceContainer
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WindowSurfaceDark

@Composable
fun VmHypervisorWindow(
    vmState: VirtualMachineState,
    onRebootVm: () -> Unit,
    onTakeSnapshot: (String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Hypervisor Overview", "16-Core CPU Scheduler", "Virtual MMU & RAM", "Storage & DMA Controller", "Snapshots & States")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WindowSurfaceDark)
            .padding(10.dp)
    ) {
        // Hypervisor Status Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF0F172A), Color(0xFF1E1B4B))))
                .border(1.dp, SleekBorderSubtle, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Brush.linearGradient(listOf(SleekAiGradientStart, SleekAiGradientEnd))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Memory, contentDescription = "VM", tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Column {
                    Text(vmState.hypervisorName, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("Architecture: ${vmState.architecture} • Uptime: ${vmState.uptimeSeconds / 60}m", color = SleekPrimary, fontSize = 10.sp)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF064E3B))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "STATUS: ${vmState.status}",
                        color = TerminalGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Navigation Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF0F172A),
            contentColor = SleekPrimary,
            edgePadding = 0.dp,
            indicator = { tabPositions ->
                if (selectedTab < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = SleekPrimary,
                        height = 2.dp
                    )
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, SleekBorderSubtle, RoundedCornerShape(8.dp))
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) SleekPrimary else TextSecondary
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tab Views
        when (selectedTab) {
            0 -> {
                // Hypervisor Overview
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // CPU Metric Box
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Virtual CPU Subsystem", color = TextSecondary, fontSize = 10.sp)
                                    Text("16 Cores @ 4.80 GHz", color = SleekPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text("Active Threads: ${vmState.activeThreads}", color = TerminalGreen, fontSize = 10.sp)
                                }
                            }

                            // RAM Metric Box
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Virtual Memory (VMM)", color = TextSecondary, fontSize = 10.sp)
                                    Text("${vmState.usedRamMb} / ${vmState.totalRamMb} MB", color = ElectricViolet, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text("Paged Pool: ${vmState.pagedPoolMb} MB", color = TextMuted, fontSize = 10.sp)
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Virtual Machine Emulation Layer", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("• Windows NT Kernel (ntoskrnl.exe build 26100) running with Ring 0 & Ring 3 privilege separation.", color = TextSecondary, fontSize = 10.sp)
                                Text("• Direct3D 12 Hardware Accelerated Graphics Pipeline with 120Hz display sync.", color = TextSecondary, fontSize = 10.sp)
                                Text("• High Precision Event Timer (HPET) & APIC Interrupt Controller synchronized.", color = TextSecondary, fontSize = 10.sp)
                                Text("• Virtual NVMe Storage Controller with direct DMA channels and NTFS translation layer.", color = TextSecondary, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }

            1 -> {
                // 16-Core CPU Scheduler
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                ) {
                    Text("REAL-TIME MULTI-CORE CPU SCHEDULER & LOAD HEATMAP", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))

                    LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(vmState.coreMetrics.chunked(2)) { pair ->
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                pair.forEach { core ->
                                    Card(
                                        modifier = Modifier.weight(1f),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                                    ) {
                                        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("Core #${core.coreId}", color = SleekPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                Text("${core.loadPercent}%", color = if (core.loadPercent > 70) Color(0xFFEF4444) else TerminalGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                            }
                                            LinearProgressIndicator(
                                                progress = { (core.loadPercent / 100f).coerceIn(0f, 1f) },
                                                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                                color = SleekPrimary,
                                                trackColor = Color(0xFF1E293B)
                                            )
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("${core.clockGhz} GHz", color = TextMuted, fontSize = 9.sp)
                                                Text("${core.temperatureC}°C", color = TextMuted, fontSize = 9.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // Virtual MMU & RAM
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Virtual Address Space & Page Tables", color = SleekPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Total Virtual RAM: 16,384 MB (16 GB Ultra DDR5 6400MHz)", color = TextPrimary, fontSize = 11.sp)
                                Text("Virtual Page Size: 4 KB (4096 bytes) • 2-Level Hierarchical Paging", color = TextSecondary, fontSize = 10.sp)
                                Text("TLB Hit Ratio: 99.4% • Page Faults: ${vmState.pageFaultsPerSec}/sec", color = TerminalGreen, fontSize = 10.sp)
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Active Process Address Space Allocation", color = ElectricViolet, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                vmState.memoryPages.forEach { page ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFF1E293B))
                                            .padding(6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(page.module, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text(page.address, color = SleekPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                        Text("${page.sizeKb} KB", color = TextSecondary, fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            3 -> {
                // Storage & DMA Controller
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Storage, contentDescription = "NVMe", tint = SleekPrimary, modifier = Modifier.size(20.dp))
                                    Text("Virtual Disk Controller (NVMe C:\\ Drive)", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Text("Capacity: ${vmState.vDiskUsedGb} GB Used / ${vmState.vDiskCapacityGb} GB Total (NTFS 3.1)", color = TextSecondary, fontSize = 10.sp)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Sequential Read: ${vmState.vDiskReadMbs.toInt()} MB/s", color = TerminalGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    Text("Sequential Write: ${vmState.vDiskWriteMbs.toInt()} MB/s", color = ElectricViolet, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Virtual Disk Partitions (C:\\ System)", color = SleekPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                val partitions = listOf(
                                    Triple("C:\\Windows\\System32", "Core OS Binaries & NTDLL", "32.4 GB"),
                                    Triple("C:\\Program Files", "Installed Applications & Hub", "48.2 GB"),
                                    Triple("C:\\Users\\HolyStunner", "User Desktop & Documents", "61.9 GB")
                                )
                                partitions.forEach { (path, desc, size) ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFF1E293B))
                                            .padding(6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(path, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                            Text(desc, color = TextMuted, fontSize = 9.sp)
                                        }
                                        Text(size, color = SleekPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            4 -> {
                // Snapshots & States
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("SAVED VM CHECKPOINTS & RESTORE STATES", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(SleekPrimary)
                                .clickable { onTakeSnapshot("User Snapshot ${System.currentTimeMillis() % 1000}") }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text("SAVE CHECKPOINT", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(vmState.snapshots) { snap ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(snap.name, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(snap.description, color = TextSecondary, fontSize = 10.sp)
                                        Text("RAM Size: ${snap.ramUsedMb} MB", color = SleekPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFF1E293B))
                                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
                                            .clickable { onRebootVm() }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text("RESTORE", color = SleekPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
