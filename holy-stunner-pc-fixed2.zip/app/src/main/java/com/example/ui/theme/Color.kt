package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Interface Theme Palette
val SleekBgDark = Color(0xFF111318)
val SleekSurfaceDark = Color(0xFF1C1B1F)
val SleekSurfaceContainer = Color(0xFF212327)
val SleekSurfaceContainerHigh = Color(0xFF2A2D32)
val SleekBorder = Color(0xFF44474E)
val SleekBorderSubtle = Color(0xFF333538)

// Sleek Accents & Highlights
val SleekPrimary = Color(0xFFD1E1FF)
val SleekOnPrimary = Color(0xFF002F64)
val SleekPrimaryContainer = Color(0xFF004A77)
val SleekOnPrimaryContainer = Color(0xFFD1E1FF)

val SleekSecondary = Color(0xFFA8C7FF)
val SleekOnSecondary = Color(0xFF003062)
val SleekSecondaryContainer = Color(0xFF1B447A)
val SleekOnSecondaryContainer = Color(0xFFD8E2FF)

val SleekAiGradientStart = Color(0xFF60A5FA)
val SleekAiGradientEnd = Color(0xFFA855F7)

val SleekSuccess = Color(0xFF6DD58C)
val SleekWarning = Color(0xFFFFB74D)
val SleekError = Color(0xFFFFB4AB)

// Text Colors
val TextPrimary = Color(0xFFE2E2E6)
val TextSecondary = Color(0xFFC4C7C5)
val TextMuted = Color(0xFF909499)

// Desktop, Window & Taskbar surfaces
val DesktopBackgroundDark = Color(0xFF111318)
val WindowSurfaceDark = Color(0xFF1C1B1F)
val WindowHeaderDark = Color(0xFF212327)
val TaskbarBackground = Color(0xFF1C1B1F)
val TaskbarBorder = Color(0xFF44474E)

// Legacy alias mappings for seamless component compatibility
val NeonCyan = SleekPrimary
val NeonCyanGlow = SleekSecondary
val ElectricViolet = SleekAiGradientStart
val ElectricPurple = SleekAiGradientEnd
val CyberPink = Color(0xFFFF85A1)
val TerminalGreen = SleekSuccess
val WarningAmber = SleekWarning
val ErrorRed = SleekError
val GlassSurface = Color(0x661C1B1F)
val GlassBorder = Color(0x6644474E)
val GlassHighlight = Color(0x44D1E1FF)

