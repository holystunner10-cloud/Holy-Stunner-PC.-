package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SystemMetrics
import com.example.ui.theme.CyberPink
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WindowSurfaceDark

@Composable
fun SettingsWindow(
    systemMetrics: SystemMetrics,
    currentWallpaperIndex: Int,
    onSelectWallpaper: (Int) -> Unit,
    onVolumeChange: (Float) -> Unit,
    onReboot: () -> Unit
) {
    var highPerformanceMode by remember { mutableStateOf(true) }
    var soundEffectsEnabled by remember { mutableStateOf(true) }

    val wallpapers = listOf(
        "Cyberpunk Grid" to listOf(Color(0xFF0F172A), Color(0xFF020617)),
        "Neon Horizon" to listOf(Color(0xFF1E1B4B), Color(0xFF0C4A6E)),
        "Deep Nebula" to listOf(Color(0xFF2E1065), Color(0xFF090D16)),
        "Matrix Rain" to listOf(Color(0xFF064E3B), Color(0xFF022C22))
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WindowSurfaceDark)
            .padding(12.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // System Spec Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Brush.linearGradient(listOf(NeonCyan, ElectricViolet))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Info, contentDescription = "Specs", tint = Color.White, modifier = Modifier.size(24.dp))
                }

                Column {
                    Text(text = "Holy Stunner PC OS Enterprise", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Build: 2026.4.192 • Quantum Kernel v3.2", color = NeonCyan, fontSize = 11.sp)
                    Text(text = "AI Coprocessor: Gemini 3.5 Flash Connected", color = TerminalGreen, fontSize = 10.sp)
                }
            }
        }

        // Section: Wallpaper Selector
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Default.Wallpaper, contentDescription = "Wallpaper", tint = NeonCyan, modifier = Modifier.size(18.dp))
                Text(text = "Desktop Background Wallpaper", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                wallpapers.forEachIndexed { index, (name, gradient) ->
                    val isSelected = currentWallpaperIndex == index
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onSelectWallpaper(index) }
                            .padding(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp, 50.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Brush.verticalGradient(gradient))
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) NeonCyan else Color(0xFF334155),
                                    shape = RoundedCornerShape(8.dp)
                                )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = name,
                            color = if (isSelected) NeonCyan else TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        // Section: System Performance & Toggles
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(text = "Preferences & Virtual Hardware", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

            // High performance toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F172A))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Quantum Turbo Acceleration", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Text("Allocates dynamic multithreading to open apps", color = TextSecondary, fontSize = 10.sp)
                }
                Switch(
                    checked = highPerformanceMode,
                    onCheckedChange = { highPerformanceMode = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan, checkedTrackColor = Color(0xFF083344))
                )
            }

            // Sound Effects toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0F172A))
                .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Synthesizer UI Audio Feedback", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Text("Play PCM click, launch and window sounds", color = TextSecondary, fontSize = 10.sp)
                }
                Switch(
                    checked = soundEffectsEnabled,
                    onCheckedChange = { soundEffectsEnabled = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = ElectricViolet, checkedTrackColor = Color(0xFF2E1065))
                )
            }
        }

        // Section: Reset & Reboot
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1E293B))
                .clickable { onReboot() }
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Default.Refresh, contentDescription = "Restart", tint = NeonCyan, modifier = Modifier.size(20.dp))
            Column {
                Text("Reboot Virtual Stunner Hypervisor", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Cleans caches and restarts system shell", color = TextSecondary, fontSize = 10.sp)
            }
        }
    }
}
