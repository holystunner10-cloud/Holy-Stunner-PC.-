package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WindowSurfaceDark

@Composable
fun CalculatorWindow() {
    var display by remember { mutableStateOf("0") }
    var operand1 by remember { mutableStateOf<Double?>(null) }
    var pendingOp by remember { mutableStateOf<String?>(null) }
    var shouldClearOnNext by remember { mutableStateOf(false) }

    fun onButtonClick(label: String) {
        when (label) {
            "C" -> {
                display = "0"
                operand1 = null
                pendingOp = null
            }
            "+", "-", "×", "÷" -> {
                operand1 = display.toDoubleOrNull()
                pendingOp = label
                shouldClearOnNext = true
            }
            "=" -> {
                val num2 = display.toDoubleOrNull()
                if (operand1 != null && num2 != null && pendingOp != null) {
                    val result = when (pendingOp) {
                        "+" -> operand1!! + num2
                        "-" -> operand1!! - num2
                        "×" -> operand1!! * num2
                        "÷" -> if (num2 != 0.0) operand1!! / num2 else Double.NaN
                        else -> num2
                    }
                    display = if (result.isNaN()) "Error" else if (result % 1.0 == 0.0) result.toLong().toString() else result.toString()
                    operand1 = null
                    pendingOp = null
                    shouldClearOnNext = true
                }
            }
            "±" -> {
                val num = display.toDoubleOrNull()
                if (num != null) {
                    val flipped = -num
                    display = if (flipped % 1.0 == 0.0) flipped.toLong().toString() else flipped.toString()
                }
            }
            "%" -> {
                val num = display.toDoubleOrNull()
                if (num != null) {
                    display = (num / 100.0).toString()
                }
            }
            "." -> {
                if (!display.contains(".")) {
                    display = "$display."
                }
            }
            else -> {
                if (display == "0" || shouldClearOnNext) {
                    display = label
                    shouldClearOnNext = false
                } else {
                    display += label
                }
            }
        }
    }

    val buttons = listOf(
        "C", "±", "%", "÷",
        "7", "8", "9", "×",
        "4", "5", "6", "-",
        "1", "2", "3", "+",
        "0", ".", "="
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WindowSurfaceDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Display Screen
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF090D16))
                .border(1.dp, NeonCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Text(
                text = display,
                color = NeonCyan,
                fontSize = 26.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.End,
                maxLines = 1
            )
        }

        // Keypad Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth().weight(1f)
        ) {
            items(buttons) { btn ->
                val isOp = btn in listOf("÷", "×", "-", "+", "=")
                val isSpecial = btn in listOf("C", "±", "%")

                Box(
                    modifier = Modifier
                        .height(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            when {
                                btn == "=" -> NeonCyan
                                isOp -> Color(0xFF0284C7)
                                isSpecial -> Color(0xFF334155)
                                else -> Color(0xFF1E293B)
                            }
                        )
                        .clickable { onButtonClick(btn) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = btn,
                        color = if (btn == "=") Color.Black else TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
