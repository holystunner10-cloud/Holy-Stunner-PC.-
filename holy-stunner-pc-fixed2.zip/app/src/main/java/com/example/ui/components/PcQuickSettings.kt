package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SystemMetrics
import com.example.ui.theme.SleekAiGradientEnd
import com.example.ui.theme.SleekAiGradientStart
import com.example.ui.theme.SleekBorder
import com.example.ui.theme.SleekBorderSubtle
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.SleekPrimaryContainer
import com.example.ui.theme.SleekSecondary
import com.example.ui.theme.SleekSurfaceContainer
import com.example.ui.theme.SleekSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PcQuickSettings(
    systemMetrics: SystemMetrics,
    onVolumeChange: (Float) -> Unit,
    onWallpaperSwitch: () -> Unit,
    onOpenSettings: () -> Unit
) {
    var isWifiOn by remember { mutableStateOf(systemMetrics.wifiConnected) }
    var isTurboOn by remember { mutableStateOf(true) }
    var isNightLight by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(0.9f) }

    Surface(
        modifier = Modifier
            .width(320.dp)
            .shadow(24.dp, RoundedCornerShape(24.dp))
            .border(1.dp, SleekBorder, RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .testTag("quick_settings_panel"),
        color = SleekSurfaceDark,
        tonalElevation = 12.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Control Center",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )

            // 2x2 Quick Toggle Grid
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // WiFi Toggle
                QuickToggleItem(
                    title = "Wi-Fi",
                    subtitle = if (isWifiOn) systemMetrics.wifiSsid else "Disconnected",
                    icon = Icons.Default.Wifi,
                    isActive = isWifiOn,
                    onClick = { isWifiOn = !isWifiOn },
                    modifier = Modifier.weight(1f)
                )

                // Turbo Performance Toggle
                QuickToggleItem(
                    title = "Performance",
                    subtitle = if (isTurboOn) "Quantum Turbo" else "Balanced",
                    icon = Icons.Default.Speed,
                    isActive = isTurboOn,
                    onClick = { isTurboOn = !isTurboOn },
                    modifier = Modifier.weight(1f)
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Wallpaper Switch
                QuickToggleItem(
                    title = "Wallpaper",
                    subtitle = "Cycle Desktop",
                    icon = Icons.Default.Wallpaper,
                    isActive = true,
                    onClick = onWallpaperSwitch,
                    modifier = Modifier.weight(1f)
                )

                // Night light
                QuickToggleItem(
                    title = "Night Shield",
                    subtitle = if (isNightLight) "Warm Glow" else "Off",
                    icon = Icons.Default.NightlightRound,
                    isActive = isNightLight,
                    onClick = { isNightLight = !isNightLight },
                    modifier = Modifier.weight(1f)
                )
            }

            // Volume Slider
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Volume", tint = SleekPrimary, modifier = Modifier.size(16.dp))
                        Text(text = "Master Volume", color = TextPrimary, fontSize = 12.sp)
                    }
                    Text(text = "${(systemMetrics.soundVolume * 100).toInt()}%", color = SleekPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = systemMetrics.soundVolume,
                    onValueChange = { onVolumeChange(it) },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = SleekPrimary,
                        activeTrackColor = SleekPrimary,
                        inactiveTrackColor = SleekSurfaceContainer
                    )
                )
            }

            // Brightness Slider
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.BrightnessMedium, contentDescription = "Brightness", tint = SleekSecondary, modifier = Modifier.size(16.dp))
                        Text(text = "Screen Brightness", color = TextPrimary, fontSize = 12.sp)
                    }
                    Text(text = "${(brightness * 100).toInt()}%", color = SleekSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = brightness,
                    onValueChange = { brightness = it },
                    valueRange = 0.2f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = SleekSecondary,
                        activeTrackColor = SleekSecondary,
                        inactiveTrackColor = SleekSurfaceContainer
                    )
                )
            }

            // Battery Status Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SleekSurfaceContainer)
                    .border(1.dp, SleekBorderSubtle, RoundedCornerShape(12.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.BatteryFull, contentDescription = "Battery", tint = Color(0xFF6DD58C), modifier = Modifier.size(18.dp))
                    Text(text = "Battery: ${systemMetrics.batteryPercent}% (${if (systemMetrics.isCharging) "Charging" else "On Battery"})", color = TextPrimary, fontSize = 12.sp)
                }
                Text(
                    text = "Optimal",
                    color = Color(0xFF6DD58C),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun QuickToggleItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (isActive) SleekPrimaryContainer else SleekSurfaceContainer)
            .border(1.dp, if (isActive) SleekPrimary.copy(alpha = 0.6f) else SleekBorderSubtle, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isActive) SleekPrimary else TextSecondary,
                modifier = Modifier.size(20.dp)
            )
            Text(text = title, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(text = subtitle, color = if (isActive) SleekSecondary else TextMuted, fontSize = 10.sp)
        }
    }
}
