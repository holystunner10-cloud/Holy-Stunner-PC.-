package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.model.DesktopIcon
import com.example.model.FileType
import com.example.ui.apps.AppInstallerWindow
import com.example.ui.apps.CalculatorWindow
import com.example.ui.apps.CodeEditorWindow
import com.example.ui.apps.CompatibilityLabWindow
import com.example.ui.apps.FileExplorerWindow
import com.example.ui.apps.HolyAiWindow
import com.example.ui.apps.MediaPlayerWindow
import com.example.ui.apps.MinesweeperWindow
import com.example.ui.apps.PaintStudioWindow
import com.example.ui.apps.SettingsWindow
import com.example.ui.apps.SpaceInvadersWindow
import com.example.ui.apps.TaskManagerWindow
import com.example.ui.apps.TerminalWindow
import com.example.ui.apps.VmHypervisorWindow
import com.example.ui.apps.WebBrowserWindow
import com.example.ui.components.PcBootScreen
import com.example.ui.components.PcCalendarFlyout
import com.example.ui.components.PcQuickSettings
import com.example.ui.components.PcStartMenu
import com.example.ui.components.PcTaskbar
import com.example.ui.components.PcWindowFrame
import com.example.ui.components.getPcIcon
import com.example.ui.theme.SleekAiGradientEnd
import com.example.ui.theme.SleekAiGradientStart
import com.example.ui.theme.SleekBgDark
import com.example.ui.theme.SleekBorderSubtle
import com.example.ui.theme.SleekOnPrimary
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.SleekSecondary
import com.example.ui.theme.SleekSurfaceContainer
import com.example.ui.theme.SleekSurfaceDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PcSystemViewModel

@Composable
fun PcDesktopScreen(
    viewModel: PcSystemViewModel
) {
    val context = LocalContext.current
    val isBooting by viewModel.isBooting.collectAsState()
    val apps by viewModel.apps.collectAsState()
    val windows by viewModel.windows.collectAsState()
    val activeWindowId by viewModel.activeWindowId.collectAsState()
    val desktopIcons by viewModel.desktopIcons.collectAsState()
    val files by viewModel.files.collectAsState()
    val systemMetrics by viewModel.systemMetrics.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val vmState by viewModel.vmState.collectAsState()
    val aiMessages by viewModel.aiMessages.collectAsState()
    val isAiThinking by viewModel.isAiThinking.collectAsState()
    val terminalLogs by viewModel.terminalLogs.collectAsState()

    var isStartMenuOpen by remember { mutableStateOf(false) }
    var isQuickSettingsOpen by remember { mutableStateOf(false) }
    var isCalendarOpen by remember { mutableStateOf(false) }
    var currentWallpaperIndex by remember { mutableIntStateOf(0) }

    val wallpapers = listOf(
        listOf(Color(0xFF111318), Color(0xFF07090C)),
        listOf(Color(0xFF141923), Color(0xFF0B0E14)),
        listOf(Color(0xFF1B1626), Color(0xFF0F0C16)),
        listOf(Color(0xFF0F1B18), Color(0xFF08100E))
    )

    if (isBooting) {
        PcBootScreen()
        return
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = SleekBgDark
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Brush.verticalGradient(wallpapers[currentWallpaperIndex]))
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            isStartMenuOpen = false
                            isQuickSettingsOpen = false
                            isCalendarOpen = false
                        }
                    )
                }
                .testTag("pc_desktop_canvas")
        ) {
            // Sleek Ambient Overlay
            Canvas(modifier = Modifier.fillMaxSize()) {
                val step = 48.dp.toPx()
                val gridColor = SleekBorderSubtle.copy(alpha = 0.25f)
                var x = 0f
                while (x < size.width) {
                    drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                    x += step
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                    y += step
                }
            }

            // Desktop Branding Watermark (Sleek Style)
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(bottom = 60.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Holy Stunner Emblem",
                        tint = SleekPrimary.copy(alpha = 0.05f),
                        modifier = Modifier.size(150.dp)
                    )
                    Text(
                        text = "HOLY STUNNER PC",
                        color = Color.White.copy(alpha = 0.05f),
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 6.sp
                    )
                }
            }

            // Desktop Icons (Arranged in flexible columns/grid on the left)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 16.dp, start = 16.dp, end = 16.dp, bottom = 64.dp)
                    .zIndex(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                desktopIcons.chunked(6).forEach { columnIcons ->
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        columnIcons.forEach { icon ->
                            DesktopIconItem(
                                icon = icon,
                                onLaunch = {
                                    isStartMenuOpen = false
                                    isQuickSettingsOpen = false
                                    isCalendarOpen = false
                                    icon.appId?.let { viewModel.openApp(it) }
                                }
                            )
                        }
                    }
                }
            }

            // Active Windows Container (Z-Indexed Windows)
            Box(modifier = Modifier.fillMaxSize().zIndex(10f)) {
                windows.forEach { win ->
                    val isActive = activeWindowId == win.id && !win.isMinimized

                    PcWindowFrame(
                        window = win,
                        isActive = isActive,
                        onFocus = { viewModel.focusWindow(win.id) },
                        onClose = { viewModel.closeWindow(win.id) },
                        onMinimize = { viewModel.minimizeWindow(win.id) },
                        onToggleMaximize = { viewModel.toggleMaximizeWindow(win.id) },
                        onMove = { x, y -> viewModel.moveWindow(win.id, x, y) },
                        onResize = { w, h -> viewModel.resizeWindow(win.id, w, h) }
                    ) {
                        // Render Window Content based on App ID
                        when (win.appId) {
                            "holy_ai" -> {
                                HolyAiWindow(
                                    messages = aiMessages,
                                    isThinking = isAiThinking,
                                    userProfile = userProfile,
                                    vmState = vmState,
                                    systemMetrics = systemMetrics,
                                    onSendMessage = { viewModel.sendHolyAiMessage(it) },
                                    onExecuteCommand = {
                                        viewModel.executeTerminalCommand(it)
                                        viewModel.openApp("terminal")
                                    },
                                    onOpenCodeInEditor = { code, lang ->
                                        viewModel.openApp("code_editor", payload = code)
                                    },
                                    onOpenCompatLab = { code ->
                                        viewModel.openApp("compat_lab", payload = code)
                                    },
                                    onOpenApp = { viewModel.openApp(it) }
                                )
                            }
                            "compat_lab" -> {
                                CompatibilityLabWindow(
                                    vmState = vmState,
                                    initialSnippet = win.payload as? String,
                                    onOpenInEditor = { code, lang ->
                                        viewModel.openApp("code_editor", payload = code)
                                    },
                                    onSaveToDesktop = { name, code ->
                                        viewModel.createFile(name, code, FileType.TEXT)
                                    }
                                )
                            }
                            "vm_hypervisor" -> {
                                VmHypervisorWindow(
                                    vmState = vmState,
                                    onTakeSnapshot = { viewModel.takeVmSnapshot(it) },
                                    onRebootVm = { viewModel.rebootVm() }
                                )
                            }
                            "app_installer" -> {
                                AppInstallerWindow(
                                    apps = apps,
                                    onInstallApp = { viewModel.installApp(it) },
                                    onUninstallApp = { viewModel.uninstallApp(it) },
                                    onLaunchApp = { viewModel.openApp(it) },
                                    onCreateCustomApp = { name, desc, cat ->
                                        viewModel.createCustomApp(name, desc, cat)
                                    }
                                )
                            }
                            "file_explorer" -> {
                                FileExplorerWindow(
                                    files = files,
                                    onCreateFile = { name, content, type ->
                                        viewModel.createFile(name, content, type)
                                    },
                                    onDeleteFile = { viewModel.deleteFile(it) },
                                    onOpenFile = { file ->
                                        when (file.type) {
                                            FileType.PYTHON, FileType.BATCH -> viewModel.openApp("code_editor", payload = file.content)
                                            FileType.IMAGE -> viewModel.openApp("paint")
                                            else -> viewModel.openApp("code_editor", payload = file.content)
                                        }
                                    }
                                )
                            }
                            "terminal" -> {
                                TerminalWindow(
                                    terminalLogs = terminalLogs,
                                    onExecuteCommand = { viewModel.executeTerminalCommand(it) }
                                )
                            }
                            "code_editor" -> {
                                CodeEditorWindow(
                                    initialCode = win.payload as? String,
                                    onSaveFile = { name, content, type ->
                                        viewModel.createFile(name, content, type)
                                    }
                                )
                            }
                            "browser" -> {
                                WebBrowserWindow()
                            }
                            "paint" -> {
                                PaintStudioWindow(
                                    onSaveToPictures = { name, content, type ->
                                        viewModel.createFile(name, content, type)
                                    }
                                )
                            }
                            "media_player" -> {
                                MediaPlayerWindow()
                            }
                            "minesweeper" -> {
                                MinesweeperWindow()
                            }
                            "space_invaders" -> {
                                SpaceInvadersWindow()
                            }
                            "task_manager" -> {
                                TaskManagerWindow(
                                    systemMetrics = systemMetrics,
                                    windows = windows,
                                    onCloseWindow = { viewModel.closeWindow(it) }
                                )
                            }
                            "calculator" -> {
                                CalculatorWindow()
                            }
                            "settings" -> {
                                SettingsWindow(
                                    systemMetrics = systemMetrics,
                                    currentWallpaperIndex = currentWallpaperIndex,
                                    onSelectWallpaper = { currentWallpaperIndex = it },
                                    onVolumeChange = { viewModel.setSoundVolume(it) },
                                    onReboot = { viewModel.rebootPc() }
                                )
                            }
                            else -> {
                                // Dynamic Custom App Window
                                CustomAppRunnerView(
                                    appName = win.title,
                                    onRunAction = {
                                        viewModel.executeTerminalCommand("echo Running virtual executable: ${win.title}")
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Start Menu Flyout
            AnimatedVisibility(
                visible = isStartMenuOpen,
                enter = slideInVertically { it / 2 } + fadeIn(),
                exit = slideOutVertically { it / 2 } + fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 8.dp, bottom = 54.dp)
                    .zIndex(100f)
            ) {
                PcStartMenu(
                    apps = apps.filter { it.isInstalled },
                    recentFiles = files,
                    userProfile = userProfile,
                    onOpenApp = {
                        isStartMenuOpen = false
                        viewModel.openApp(it)
                    },
                    onOpenFile = { file ->
                        isStartMenuOpen = false
                        viewModel.openApp("code_editor", payload = file.content)
                    },
                    onReboot = {
                        isStartMenuOpen = false
                        viewModel.rebootPc()
                    },
                    onHolyAiPrompt = { prompt ->
                        isStartMenuOpen = false
                        viewModel.openApp("holy_ai")
                        viewModel.sendHolyAiMessage(prompt)
                    },
                    onSignInGoogle = {
                        viewModel.signInWithGoogle(context)
                    }
                )
            }

            // Quick Settings Flyout
            AnimatedVisibility(
                visible = isQuickSettingsOpen,
                enter = slideInVertically { it / 2 } + fadeIn(),
                exit = slideOutVertically { it / 2 } + fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 60.dp, bottom = 54.dp)
                    .zIndex(100f)
            ) {
                PcQuickSettings(
                    systemMetrics = systemMetrics,
                    onVolumeChange = { viewModel.setSoundVolume(it) },
                    onWallpaperSwitch = { currentWallpaperIndex = (currentWallpaperIndex + 1) % wallpapers.size },
                    onOpenSettings = {
                        isQuickSettingsOpen = false
                        viewModel.openApp("settings")
                    }
                )
            }

            // Calendar & Clock Flyout
            AnimatedVisibility(
                visible = isCalendarOpen,
                enter = slideInVertically { it / 2 } + fadeIn(),
                exit = slideOutVertically { it / 2 } + fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 8.dp, bottom = 54.dp)
                    .zIndex(100f)
            ) {
                PcCalendarFlyout()
            }

            // Taskbar (Docked at Bottom)
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .zIndex(90f)
            ) {
                PcTaskbar(
                    apps = apps,
                    windows = windows,
                    activeWindowId = activeWindowId,
                    systemMetrics = systemMetrics,
                    isStartMenuOpen = isStartMenuOpen,
                    onToggleStartMenu = {
                        isStartMenuOpen = !isStartMenuOpen
                        isQuickSettingsOpen = false
                        isCalendarOpen = false
                    },
                    onToggleQuickSettings = {
                        isQuickSettingsOpen = !isQuickSettingsOpen
                        isStartMenuOpen = false
                        isCalendarOpen = false
                    },
                    onToggleCalendar = {
                        isCalendarOpen = !isCalendarOpen
                        isStartMenuOpen = false
                        isQuickSettingsOpen = false
                    },
                    onOpenApp = {
                        isStartMenuOpen = false
                        viewModel.openApp(it)
                    },
                    onWindowClick = { win ->
                        if (win.id == activeWindowId && !win.isMinimized) {
                            viewModel.minimizeWindow(win.id)
                        } else {
                            viewModel.focusWindow(win.id)
                        }
                    },
                    onHolyAiClick = {
                        viewModel.openApp("holy_ai")
                    },
                    onShowDesktop = {
                        windows.forEach { if (!it.isMinimized) viewModel.minimizeWindow(it.id) }
                    }
                )
            }
        }
    }
}

@Composable
private fun DesktopIconItem(
    icon: DesktopIcon,
    onLaunch: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(76.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onLaunch() }
            .padding(vertical = 6.dp, horizontal = 4.dp)
            .testTag("desktop_icon_${icon.id}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(SleekSurfaceContainer)
                .border(1.dp, SleekBorderSubtle, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = getPcIcon(icon.iconName),
                contentDescription = icon.title,
                tint = SleekPrimary,
                modifier = Modifier.size(26.dp)
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = icon.title,
            color = TextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun CustomAppRunnerView(
    appName: String,
    onRunAction: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SleekSurfaceDark)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(SleekAiGradientStart, SleekAiGradientEnd))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = "Run", tint = Color.White, modifier = Modifier.size(34.dp))
        }

        Text(text = appName, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(text = "Virtual Executable Binary • Runtime 64-bit", color = SleekSecondary, fontSize = 11.sp)
        Text(
            text = "This program was installed into Holy Stunner PC via Software Hub / .EXE Setup Wizard.",
            color = TextSecondary,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(SleekPrimary)
                .clickable { onRunAction() }
                .padding(horizontal = 22.dp, vertical = 10.dp)
        ) {
            Text("Execute Routine in Terminal", color = SleekOnPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}
