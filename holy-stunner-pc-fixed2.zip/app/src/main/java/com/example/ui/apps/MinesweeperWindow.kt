package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SentimentDissatisfied
import androidx.compose.material.icons.filled.SentimentSatisfied
import androidx.compose.material.icons.filled.SentimentVerySatisfied
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WindowSurfaceDark
import kotlin.random.Random

data class Cell(
    val row: Int,
    val col: Int,
    var isMine: Boolean = false,
    var isRevealed: Boolean = false,
    var isFlagged: Boolean = false,
    var neighborMines: Int = 0
)

@Composable
fun MinesweeperWindow() {
    val rows = 8
    val cols = 8
    val totalMines = 10

    var isGameOver by remember { mutableStateOf(false) }
    var isGameWon by remember { mutableStateOf(false) }
    var flagMode by remember { mutableStateOf(false) }

    fun generateGrid(): List<Cell> {
        val list = mutableListOf<Cell>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                list.add(Cell(r, c))
            }
        }
        var placed = 0
        while (placed < totalMines) {
            val idx = Random.nextInt(list.size)
            if (!list[idx].isMine) {
                list[idx].isMine = true
                placed++
            }
        }
        // Calculate neighbors
        for (cell in list) {
            if (!cell.isMine) {
                var count = 0
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        if (dr == 0 && dc == 0) continue
                        val nr = cell.row + dr
                        val nc = cell.col + dc
                        if (nr in 0 until rows && nc in 0 until cols) {
                            val neighbor = list.find { it.row == nr && it.col == nc }
                            if (neighbor?.isMine == true) count++
                        }
                    }
                }
                cell.neighborMines = count
            }
        }
        return list
    }

    val grid = remember { mutableStateListOf<Cell>().apply { addAll(generateGrid()) } }

    fun restart() {
        isGameOver = false
        isGameWon = false
        grid.clear()
        grid.addAll(generateGrid())
    }

    fun reveal(cell: Cell) {
        if (cell.isRevealed || cell.isFlagged || isGameOver || isGameWon) return
        val idx = grid.indexOf(cell)
        if (idx == -1) return
        val updated = cell.copy(isRevealed = true)
        grid[idx] = updated

        if (cell.isMine) {
            isGameOver = true
            return
        }

        if (cell.neighborMines == 0) {
            for (dr in -1..1) {
                for (dc in -1..1) {
                    val nr = cell.row + dr
                    val nc = cell.col + dc
                    if (nr in 0 until rows && nc in 0 until cols) {
                        val neighbor = grid.find { it.row == nr && it.col == nc }
                        if (neighbor != null && !neighbor.isRevealed) {
                            reveal(neighbor)
                        }
                    }
                }
            }
        }

        // Check win
        val unrevealedSafe = grid.count { !it.isMine && !it.isRevealed }
        if (unrevealedSafe == 0) {
            isGameWon = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WindowSurfaceDark)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Status Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0F172A))
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "💣 $totalMines",
                color = Color(0xFFF87171),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )

            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF1E293B))
                    .clickable { restart() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when {
                        isGameWon -> Icons.Default.SentimentVerySatisfied
                        isGameOver -> Icons.Default.SentimentDissatisfied
                        else -> Icons.Default.SentimentSatisfied
                    },
                    contentDescription = "Restart",
                    tint = if (isGameWon) NeonCyan else Color.Yellow,
                    modifier = Modifier.size(20.dp)
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (flagMode) Color(0xFFEF4444) else Color(0xFF1E293B))
                    .clickable { flagMode = !flagMode }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.Flag, contentDescription = "Flag", tint = Color.White, modifier = Modifier.size(13.dp))
                    Text(if (flagMode) "Flag ON" else "Flag OFF", color = Color.White, fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Grid
        Box(
            modifier = Modifier
                .size(280.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF090D16))
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                .padding(6.dp)
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(cols),
                verticalArrangement = Arrangement.spacedBy(2.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(grid.size) { i ->
                    val cell = grid[i]
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                when {
                                    cell.isRevealed && cell.isMine -> Color(0xFF7F1D1D)
                                    cell.isRevealed -> Color(0xFF1E293B)
                                    else -> Color(0xFF334155)
                                }
                            )
                            .clickable {
                                if (flagMode) {
                                    val idx = grid.indexOf(cell)
                                    if (idx != -1 && !cell.isRevealed) {
                                        grid[idx] = cell.copy(isFlagged = !cell.isFlagged)
                                    }
                                } else {
                                    reveal(cell)
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        when {
                            cell.isFlagged -> Text("🚩", fontSize = 12.sp)
                            cell.isRevealed && cell.isMine -> Text("💣", fontSize = 12.sp)
                            cell.isRevealed && cell.neighborMines > 0 -> {
                                val numColor = when (cell.neighborMines) {
                                    1 -> NeonCyan
                                    2 -> Color(0xFF34D399)
                                    3 -> Color(0xFFF87171)
                                    else -> Color(0xFFA855F7)
                                }
                                Text(
                                    text = "${cell.neighborMines}",
                                    color = numColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
