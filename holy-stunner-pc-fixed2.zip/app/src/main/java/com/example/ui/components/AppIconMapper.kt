package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector

@Composable
fun getPcIcon(iconName: String): ImageVector {
    return when (iconName) {
        "smart_toy" -> Icons.Default.SmartToy
        "storefront" -> Icons.Default.Storefront
        "folder" -> Icons.Default.Folder
        "terminal" -> Icons.Default.Terminal
        "code" -> Icons.Default.Code
        "public" -> Icons.Default.Public
        "brush" -> Icons.Default.Brush
        "music_note" -> Icons.Default.MusicNote
        "grid_view" -> Icons.Default.GridView
        "sports_esports" -> Icons.Default.SportsEsports
        "monitoring" -> Icons.Default.Speed
        "assessment" -> Icons.Default.Assessment
        "calculate" -> Icons.Default.Calculate
        "view_in_ar" -> Icons.Default.ViewInAr
        "settings" -> Icons.Default.Settings
        "description" -> Icons.Default.Description
        "image" -> Icons.Default.Image
        "tune" -> Icons.Default.Tune
        "memory" -> Icons.Default.Memory
        "storage" -> Icons.Default.Storage
        "account_circle" -> Icons.Default.AccountCircle
        "help_outline" -> Icons.Default.HelpOutline
        "dns" -> Icons.Default.Dns
        else -> Icons.Default.Widgets
    }
}
