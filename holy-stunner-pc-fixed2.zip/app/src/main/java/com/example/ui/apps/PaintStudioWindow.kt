package com.example.ui.apps

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FileType
import com.example.ui.theme.CyberPink
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WindowSurfaceDark

data class DrawPoint(
    val offset: Offset,
    val color: Color,
    val strokeWidth: Float
)

@Composable
fun PaintStudioWindow(
    onSaveToPictures: (String, String, FileType) -> Unit
) {
    val points = remember { mutableStateListOf<DrawPoint?>() }
    var selectedColor by remember { mutableStateOf(NeonCyan) }
    var strokeWidth by remember { mutableFloatStateOf(6f) }
    var isEraser by remember { mutableStateOf(false) }

    val palette = listOf(
        NeonCyan,
        ElectricViolet,
        CyberPink,
        TerminalGreen,
        Color(0xFFFACC15),
        Color(0xFFEF4444),
        Color.White,
        Color(0xFF090D16)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WindowSurfaceDark)
            .padding(10.dp)
    ) {
        // Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0F172A))
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Colors palette
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                palette.forEach { color ->
                    val isSelected = !isEraser && selectedColor == color
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(color)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) Color.White else Color(0xFF475569),
                                shape = CircleShape
                            )
                            .clickable {
                                isEraser = false
                                selectedColor = color
                            }
                    )
                }
            }

            // Actions (Eraser, Clear, Save)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                // Eraser Toggle
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isEraser) NeonCyan else Color(0xFF1E293B))
                        .clickable { isEraser = !isEraser }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("Eraser", color = if (isEraser) Color.Black else TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Clear
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF1E293B))
                        .clickable { points.clear() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFFF87171), modifier = Modifier.size(14.dp))
                }

                // Save
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(NeonCyan)
                        .clickable {
                            onSaveToPictures("artwork_${System.currentTimeMillis()}.png", "IMAGE_BITMAP_DATA", FileType.IMAGE)
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        Icon(Icons.Default.Save, contentDescription = "Save", tint = Color.Black, modifier = Modifier.size(13.dp))
                        Text("Save", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Drawing Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF060910))
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(selectedColor, strokeWidth, isEraser) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                points.add(
                                    DrawPoint(
                                        offset = offset,
                                        color = if (isEraser) Color(0xFF060910) else selectedColor,
                                        strokeWidth = if (isEraser) strokeWidth * 3 else strokeWidth
                                    )
                                )
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                points.add(
                                    DrawPoint(
                                        offset = change.position,
                                        color = if (isEraser) Color(0xFF060910) else selectedColor,
                                        strokeWidth = if (isEraser) strokeWidth * 3 else strokeWidth
                                    )
                                )
                            },
                            onDragEnd = {
                                points.add(null)
                            }
                        )
                    }
            ) {
                for (i in 0 until points.size - 1) {
                    val current = points[i]
                    val next = points[i + 1]
                    if (current != null && next != null) {
                        drawLine(
                            color = current.color,
                            start = current.offset,
                            end = next.offset,
                            strokeWidth = current.strokeWidth,
                            cap = StrokeCap.Round
                        )
                    }
                }
            }
        }
    }
}
