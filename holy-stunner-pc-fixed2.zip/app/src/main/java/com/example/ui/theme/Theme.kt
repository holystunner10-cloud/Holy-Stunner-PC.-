package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val HolyPcColorScheme = darkColorScheme(
    primary = SleekPrimary,
    onPrimary = SleekOnPrimary,
    primaryContainer = SleekPrimaryContainer,
    onPrimaryContainer = SleekOnPrimaryContainer,
    secondary = SleekSecondary,
    onSecondary = SleekOnSecondary,
    secondaryContainer = SleekSecondaryContainer,
    onSecondaryContainer = SleekOnSecondaryContainer,
    tertiary = SleekAiGradientEnd,
    background = SleekBgDark,
    onBackground = TextPrimary,
    surface = SleekSurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SleekSurfaceContainer,
    onSurfaceVariant = TextSecondary,
    outline = SleekBorder,
    outlineVariant = SleekBorderSubtle,
    error = SleekError
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = HolyPcColorScheme,
        typography = Typography,
        content = content
    )
}
