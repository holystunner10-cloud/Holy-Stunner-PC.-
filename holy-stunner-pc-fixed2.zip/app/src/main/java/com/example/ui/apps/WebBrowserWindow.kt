package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberPink
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WindowSurfaceDark
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun WebBrowserWindow() {
    var urlInput by remember { mutableStateOf("https://holystunner.pc/portal") }
    var currentUrl by remember { mutableStateOf("https://holystunner.pc/portal") }
    var isLoading by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    val bookmarks = listOf(
        "⚡ Holy AI Hub" to "https://holystunner.pc/portal",
        "🌐 Tech News" to "https://news.quantumtech.io",
        "🐍 Python Docs" to "https://docs.python.org",
        "🎮 Arcade Arena" to "https://arcade.holystunner.pc"
    )

    fun navigateTo(url: String) {
        urlInput = url
        currentUrl = url
        isLoading = true
        coroutineScope.launch {
            delay(400)
            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WindowSurfaceDark)
            .padding(8.dp)
    ) {
        // Browser navigation bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0F172A))
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = TextSecondary,
                modifier = Modifier
                    .size(18.dp)
                    .clickable { navigateTo("https://holystunner.pc/portal") }
            )
            Icon(
                Icons.Default.Refresh,
                contentDescription = "Reload",
                tint = NeonCyan,
                modifier = Modifier
                    .size(18.dp)
                    .clickable { navigateTo(currentUrl) }
            )

            // Address bar
            OutlinedTextField(
                value = urlInput,
                onValueChange = { urlInput = it },
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
                    .testTag("browser_address_bar"),
                singleLine = true,
                shape = RoundedCornerShape(6.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedContainerColor = Color(0xFF1E293B),
                    unfocusedContainerColor = Color(0xFF1E293B),
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(NeonCyan)
                    .clickable { navigateTo(urlInput) }
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Text("GO", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (isLoading) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp),
                color = NeonCyan,
                trackColor = Color.Transparent
            )
        } else {
            Spacer(modifier = Modifier.height(4.dp))
        }

        // Bookmarks Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            bookmarks.forEach { (name, link) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (currentUrl == link) Color(0xFF1E293B) else Color(0xFF0F172A))
                        .border(1.dp, if (currentUrl == link) NeonCyan else Color(0xFF334155), RoundedCornerShape(6.dp))
                        .clickable { navigateTo(link) }
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(text = name, color = if (currentUrl == link) NeonCyan else TextPrimary, fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Web Content Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF090D16))
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                .padding(12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            when {
                "portal" in currentUrl -> {
                    // Holy AI Portal
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Brush.horizontalGradient(listOf(Color(0xFF1E1B4B), Color(0xFF0C4A6E))))
                                .padding(16.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("⚡ HOLY STUNNER PC NETWORK", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Text("The official high-speed cloud gateway for simulated PC computing.", color = Color(0xFFA5F3FC), fontSize = 11.sp)
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Software Repositories", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("Over 500+ virtual PC packages available for instant installation in Software Hub.", color = TextSecondary, fontSize = 10.sp)
                                }
                            }

                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Neural Copilot v3.5", color = ElectricViolet, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("Direct access to Gemini AI architecture for automated code & system scripting.", color = TextSecondary, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
                "news" in currentUrl -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("🌐 Quantum Tech Daily News", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("• Android PC Emulation hits record 120 FPS multi-window throughput", color = NeonCyan, fontSize = 12.sp)
                        Text("• New Gemini Flash models integrated natively into Holy Stunner desktop OS", color = TextPrimary, fontSize = 11.sp)
                        Text("• Cyberpunk UI trends lead desktop ergonomics across modern developers", color = TextSecondary, fontSize = 11.sp)
                    }
                }
                "python" in currentUrl -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("🐍 Python 3.12 Reference Manual", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("Built-in Modules Available in Stunner PC:", color = TextSecondary, fontSize = 12.sp)
                        Text("• math, time, random, sys, os, json, socket, threading", color = TerminalGreen, fontSize = 11.sp)
                        Text("Use VS Code Pro to write and run any Python logic locally on your Android PC.", color = TextSecondary, fontSize = 11.sp)
                    }
                }
                else -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Web Page: $currentUrl", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("Status: 200 OK • SSL Encrypted (TLS 1.3)", color = TerminalGreen, fontSize = 11.sp)
                        Text("Simulated page rendering loaded successfully in Stunner Chrome.", color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
