package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PcApp
import com.example.model.PcWindow
import com.example.model.SystemMetrics
import com.example.ui.theme.SleekAiGradientEnd
import com.example.ui.theme.SleekAiGradientStart
import com.example.ui.theme.SleekBorder
import com.example.ui.theme.SleekBorderSubtle
import com.example.ui.theme.SleekOnPrimary
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.SleekPrimaryContainer
import com.example.ui.theme.SleekSecondary
import com.example.ui.theme.SleekSurfaceContainer
import com.example.ui.theme.SleekSurfaceDark
import com.example.ui.theme.TaskbarBackground
import com.example.ui.theme.TaskbarBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PcTaskbar(
    apps: List<PcApp>,
    windows: List<PcWindow>,
    activeWindowId: String?,
    systemMetrics: SystemMetrics,
    isStartMenuOpen: Boolean,
    onToggleStartMenu: () -> Unit,
    onToggleQuickSettings: () -> Unit,
    onToggleCalendar: () -> Unit,
    onOpenApp: (String) -> Unit,
    onWindowClick: (PcWindow) -> Unit,
    onHolyAiClick: () -> Unit,
    onShowDesktop: () -> Unit
) {
    var currentTime by remember { mutableStateOf("") }
    var currentDate by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val dateFormat = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
        while (true) {
            val now = Date()
            currentTime = timeFormat.format(now)
            currentDate = dateFormat.format(now)
            delay(1000)
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "ai_pulse")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .border(width = 1.dp, color = SleekBorder)
            .testTag("pc_taskbar"),
        color = SleekSurfaceDark,
        tonalElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left & Center area: Start Button + Holy AI Pill + App Icons
            Row(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Start Button (Sleek container)
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isStartMenuOpen) SleekPrimaryContainer
                            else SleekSurfaceContainer
                        )
                        .border(
                            width = 1.dp,
                            color = if (isStartMenuOpen) SleekPrimary else SleekBorder,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { onToggleStartMenu() }
                        .testTag("start_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.GridView,
                        contentDescription = "Start Menu",
                        tint = if (isStartMenuOpen) SleekPrimary else TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Holy Stunner AI Quick Orb / Sleek Pill
                Box(
                    modifier = Modifier
                        .height(38.dp)
                        .clip(RoundedCornerShape(19.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    SleekAiGradientStart.copy(alpha = 0.25f),
                                    SleekAiGradientEnd.copy(alpha = 0.25f)
                                )
                            )
                        )
                        .border(
                            width = 1.dp,
                            color = SleekAiGradientStart.copy(alpha = pulseGlow),
                            shape = RoundedCornerShape(19.dp)
                        )
                        .clickable { onHolyAiClick() }
                        .padding(horizontal = 12.dp)
                        .testTag("holy_ai_orb"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Brush.linearGradient(listOf(SleekAiGradientStart, SleekAiGradientEnd))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Holy AI",
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                        Text(
                            text = "Holy AI",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Pinned / Running Applications
                val visibleApps = apps.filter { it.isInstalled }
                visibleApps.forEach { app ->
                    val openWin = windows.find { it.appId == app.id }
                    val isRunning = openWin != null
                    val isActive = isRunning && activeWindowId == openWin?.id && !openWin.isMinimized

                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isActive) SleekPrimaryContainer
                                else if (isRunning) SleekSurfaceContainer
                                else Color.Transparent
                            )
                            .border(
                                width = 1.dp,
                                color = if (isActive) SleekPrimary.copy(alpha = 0.6f) else if (isRunning) SleekBorderSubtle else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                if (openWin != null) {
                                    onWindowClick(openWin)
                                } else {
                                    onOpenApp(app.id)
                                }
                            }
                            .testTag("taskbar_app_${app.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = getPcIcon(app.iconName),
                            contentDescription = app.name,
                            tint = if (isActive) SleekPrimary else if (isRunning) TextPrimary else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )

                        // Running Indicator Pill
                        if (isRunning) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 3.dp)
                                    .width(if (isActive) 16.dp else 6.dp)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (isActive) SleekPrimary else TextMuted)
                            )
                        }
                    }
                }
            }

            // Right area: System Tray & Clock & Show Desktop
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Quick Settings (WiFi, Sound, Battery pill)
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(SleekSurfaceContainer)
                        .border(1.dp, SleekBorderSubtle, RoundedCornerShape(10.dp))
                        .clickable { onToggleQuickSettings() }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag("quick_settings_button"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Wifi,
                        contentDescription = "Wi-Fi",
                        tint = if (systemMetrics.wifiConnected) SleekPrimary else TextSecondary,
                        modifier = Modifier.size(15.dp)
                    )

                    Icon(
                        imageVector = if (systemMetrics.soundVolume <= 0.05f) Icons.Default.VolumeMute
                        else if (systemMetrics.soundVolume < 0.5f) Icons.Default.VolumeDown
                        else Icons.Default.VolumeUp,
                        contentDescription = "Volume",
                        tint = TextPrimary,
                        modifier = Modifier.size(15.dp)
                    )

                    Icon(
                        imageVector = if (systemMetrics.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                        contentDescription = "Battery",
                        tint = if (systemMetrics.batteryPercent > 20) Color(0xFF6DD58C) else Color(0xFFFFB4AB),
                        modifier = Modifier.size(16.dp)
                    )
                }

                // Clock & Date (Sleek badge)
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(SleekSurfaceContainer)
                        .border(1.dp, SleekBorderSubtle, RoundedCornerShape(10.dp))
                        .clickable { onToggleCalendar() }
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                        .testTag("clock_button"),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = if (currentTime.isNotEmpty()) currentTime else "12:00",
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (currentDate.isNotEmpty()) currentDate else "01/01/2026",
                        color = TextSecondary,
                        fontSize = 9.sp
                    )
                }

                // Show Desktop strip
                Box(
                    modifier = Modifier
                        .width(6.dp)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(3.dp))
                        .background(SleekBorder)
                        .clickable { onShowDesktop() }
                )
            }
        }
    }
}
