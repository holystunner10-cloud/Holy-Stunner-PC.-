package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.FilterNone
import androidx.compose.material.icons.filled.Minimize
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.model.PcWindow
import com.example.ui.theme.SleekBorder
import com.example.ui.theme.SleekBorderSubtle
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.SleekSecondary
import com.example.ui.theme.SleekSurfaceContainer
import com.example.ui.theme.SleekSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WindowHeaderDark
import com.example.ui.theme.WindowSurfaceDark
import kotlin.math.roundToInt

@Composable
fun PcWindowFrame(
    window: PcWindow,
    isActive: Boolean,
    onFocus: () -> Unit,
    onClose: () -> Unit,
    onMinimize: () -> Unit,
    onToggleMaximize: () -> Unit,
    onMove: (Float, Float) -> Unit,
    onResize: (Float, Float) -> Unit,
    content: @Composable () -> Unit
) {
    if (window.isMinimized) return

    val animatedBorderAlpha by animateFloatAsState(
        targetValue = if (isActive) 0.9f else 0.4f,
        label = "border_alpha"
    )

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val maxAvailableWidth = maxWidth.value
        val maxAvailableHeight = (maxHeight.value - 52f).coerceAtLeast(200f) // leave space for sleek taskbar

        val currentWidth = if (window.isMaximized) maxAvailableWidth else window.width.coerceAtMost(maxAvailableWidth)
        val currentHeight = if (window.isMaximized) maxAvailableHeight else window.height.coerceAtMost(maxAvailableHeight)
        val currentX = if (window.isMaximized) 0f else window.x.coerceIn(0f, (maxAvailableWidth - 100f).coerceAtLeast(0f))
        val currentY = if (window.isMaximized) 0f else window.y.coerceIn(0f, (maxAvailableHeight - 80f).coerceAtLeast(0f))

        Surface(
            modifier = Modifier
                .offset { IntOffset(currentX.dp.roundToPx(), currentY.dp.roundToPx()) }
                .width(currentWidth.dp)
                .height(currentHeight.dp)
                .zIndex(window.zIndex)
                .shadow(
                    elevation = if (isActive) 20.dp else 8.dp,
                    shape = if (window.isMaximized) RoundedCornerShape(0.dp) else RoundedCornerShape(16.dp)
                )
                .border(
                    width = if (isActive) 1.5.dp else 1.dp,
                    color = if (isActive) SleekPrimary.copy(alpha = animatedBorderAlpha) else SleekBorder,
                    shape = if (window.isMaximized) RoundedCornerShape(0.dp) else RoundedCornerShape(16.dp)
                )
                .clip(if (window.isMaximized) RoundedCornerShape(0.dp) else RoundedCornerShape(16.dp))
                .pointerInput(window.id) {
                    detectTapGestures(onPress = { onFocus() })
                }
                .testTag("window_${window.appId}"),
            color = SleekSurfaceDark,
            tonalElevation = 4.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Sleek Window Title Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .background(
                            if (isActive) SleekSurfaceContainer else SleekSurfaceDark
                        )
                        .border(
                            width = 0.5.dp,
                            color = SleekBorderSubtle
                        )
                        .pointerInput(window.id, window.isMaximized) {
                            if (!window.isMaximized) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    onMove(currentX + dragAmount.x / density, currentY + dragAmount.y / density)
                                }
                            }
                        }
                        .pointerInput(window.id) {
                            detectTapGestures(
                                onDoubleTap = { onToggleMaximize() },
                                onPress = { onFocus() }
                            )
                        }
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // App Icon & Title
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = getPcIcon(window.iconName),
                            contentDescription = window.title,
                            tint = if (isActive) SleekPrimary else TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = window.title,
                            color = if (isActive) TextPrimary else TextSecondary,
                            fontSize = 13.sp,
                            fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Window Action Buttons (Minimize, Maximize, Close)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Minimize
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(SleekSurfaceDark)
                                .clickable { onMinimize() }
                                .padding(4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Minimize,
                                contentDescription = "Minimize",
                                tint = TextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }

                        // Maximize / Restore
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(SleekSurfaceDark)
                                .clickable { onToggleMaximize() }
                                .padding(4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (window.isMaximized) Icons.Default.FilterNone else Icons.Default.CropSquare,
                                contentDescription = if (window.isMaximized) "Restore" else "Maximize",
                                tint = TextSecondary,
                                modifier = Modifier.size(13.dp)
                            )
                        }

                        // Close (with red highlight)
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x22FFB4AB))
                                .clickable { onClose() }
                                .padding(4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color(0xFFFFB4AB),
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                }

                // Window Main Content Area
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(SleekSurfaceDark)
                ) {
                    content()

                    // Resize handle (bottom-right corner) if not maximized
                    if (!window.isMaximized) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(24.dp)
                                .pointerInput(window.id) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        onResize(
                                            currentWidth + dragAmount.x / density,
                                            currentHeight + dragAmount.y / density
                                        )
                                    }
                                }
                                .padding(4.dp),
                            contentAlignment = Alignment.BottomEnd
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(SleekPrimary.copy(alpha = 0.6f), RoundedCornerShape(2.dp))
                            )
                        }
                    }
                }
            }
        }
    }
}
