package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PcWallpaper
import com.example.model.WallpaperThemeType
import com.example.ui.theme.SleekBorderSubtle
import com.example.ui.theme.TerminalGreen

@Composable
fun PcDesktopWallpaper(
    wallpaper: PcWallpaper,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(wallpaper.gradientColors))
    ) {
        when (wallpaper.type) {
            WallpaperThemeType.GREEN_TEXT_HOLY_STUNNER -> {
                GreenTextHolyStunnerWallpaperContent()
            }
            WallpaperThemeType.EMERALD_CRT -> {
                EmeraldCrtWallpaperContent()
            }
            else -> {
                DefaultCyberGridWallpaperContent(wallpaper)
            }
        }
    }
}

@Composable
private fun GreenTextHolyStunnerWallpaperContent() {
    val infiniteTransition = rememberInfiniteTransition(label = "matrix_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )
    val scanlineOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scanline_offset"
    )

    // Matrix background grid & digital scanlines canvas
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // Subtle matrix vertical column lines
        val colStep = 40.dp.toPx()
        var colX = 0f
        while (colX < width) {
            drawLine(
                color = Color(0xFF0D5329).copy(alpha = 0.18f),
                start = Offset(colX, 0f),
                end = Offset(colX, height),
                strokeWidth = 1f
            )
            colX += colStep
        }

        // Horizontal scanlines
        val rowStep = 12.dp.toPx()
        var rowY = scanlineOffset % rowStep
        while (rowY < height) {
            drawLine(
                color = Color(0xFF10B981).copy(alpha = 0.04f),
                start = Offset(0f, rowY),
                end = Offset(width, rowY),
                strokeWidth = 1.2f
            )
            rowY += rowStep
        }
    }

    // Top Right Telemetry HUD Overlay in Landscape
    Box(
        modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(top = 16.dp, end = 24.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xCC021A0C))
            .border(1.dp, Color(0xFF0D5329), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF10B981))
            )
            Text(
                text = "HOLY_STUNNER_SYS // 16-CORE HYPERVISOR // PE32+ OK",
                color = Color(0xFF34D399),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }

    // Centerpiece: Glowing Green "HOLY STUNNER" Typography & HUD
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 48.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // High-Tech Header Label
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF064E22).copy(alpha = 0.6f))
                    .border(1.dp, Color(0xFF10B981).copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 10.dp, vertical = 3.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = "Terminal",
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = "[ QUANTUM PC ENVIRONMENT // READY ]",
                    color = Color(0xFF6EE7B7),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Main Green Text "HOLY STUNNER"
            Text(
                text = "HOLY STUNNER",
                style = TextStyle(
                    color = Color(0xFF10B981).copy(alpha = pulseAlpha),
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 10.sp,
                    shadow = Shadow(
                        color = Color(0xFF10B981).copy(alpha = 0.8f),
                        offset = Offset(0f, 0f),
                        blurRadius = 24f
                    )
                )
            )

            // Sub-Title Cyber Text
            Text(
                text = "EMULATED PC SYSTEM OS • HYPERVISOR v4.2 • NEURAL COPILOT",
                color = Color(0xFF34D399).copy(alpha = 0.6f),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Medium,
                letterSpacing = 3.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Bottom Green Matrix Micro-Pillars
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("RAM: 16GB DDR5 DMA", color = Color(0xFF059669).copy(alpha = 0.7f), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("•", color = Color(0xFF059669).copy(alpha = 0.7f), fontSize = 9.sp)
                Text("CPU: 16x QUANTUM CORES", color = Color(0xFF059669).copy(alpha = 0.7f), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("•", color = Color(0xFF059669).copy(alpha = 0.7f), fontSize = 9.sp)
                Text("DISC C:\\ 512GB NVMe", color = Color(0xFF059669).copy(alpha = 0.7f), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun EmeraldCrtWallpaperContent() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val step = 16.dp.toPx()
        var y = 0f
        while (y < size.height) {
            drawLine(
                color = Color(0xFF22C55E).copy(alpha = 0.05f),
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1f
            )
            y += step
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 60.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "HOLY STUNNER CRT",
                color = Color(0xFF22C55E).copy(alpha = 0.3f),
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 8.sp
            )
        }
    }
}

@Composable
private fun DefaultCyberGridWallpaperContent(wallpaper: PcWallpaper) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val step = 48.dp.toPx()
        val gridColor = wallpaper.accentColor.copy(alpha = 0.08f)
        var x = 0f
        while (x < size.width) {
            drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
            x += step
        }
        var y = 0f
        while (y < size.height) {
            drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
            y += step
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 60.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = "Holy Stunner Emblem",
                tint = wallpaper.accentColor.copy(alpha = 0.08f),
                modifier = Modifier.size(140.dp)
            )
            Text(
                text = "HOLY STUNNER PC",
                color = Color.White.copy(alpha = 0.08f),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 6.sp
            )
        }
    }
}
