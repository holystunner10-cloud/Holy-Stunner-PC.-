package com.example

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.PcDesktopScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.PcSystemViewModel

const val ORIENTATION_PREFS_NAME = "holy_stunner_prefs"
const val ORIENTATION_PREF_KEY = "screen_orientation_mode"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySavedOrientation()
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    val viewModel: PcSystemViewModel = viewModel()
                    PcDesktopScreen(
                        viewModel = viewModel,
                        onOrientationChange = { mode ->
                            saveOrientationPref(mode)
                            applyOrientation(mode)
                        }
                    )
                }
            }
        }
    }

    private fun applySavedOrientation() {
        val prefs = getSharedPreferences(ORIENTATION_PREFS_NAME, MODE_PRIVATE)
        val mode = prefs.getString(ORIENTATION_PREF_KEY, "landscape") ?: "landscape"
        applyOrientation(mode)
    }

    private fun saveOrientationPref(mode: String) {
        val prefs = getSharedPreferences(ORIENTATION_PREFS_NAME, MODE_PRIVATE)
        prefs.edit().putString(ORIENTATION_PREF_KEY, mode).apply()
    }

    private fun applyOrientation(mode: String) {
        requestedOrientation = when (mode) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            "auto" -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }
}
