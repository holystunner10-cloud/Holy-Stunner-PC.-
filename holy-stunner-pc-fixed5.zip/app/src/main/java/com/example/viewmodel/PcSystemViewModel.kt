package com.example.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.AppCategory
import com.example.model.DesktopIcon
import com.example.model.FileType
import com.example.model.HolyAiMessage
import com.example.model.PcApp
import com.example.model.PcFileItem
import com.example.model.PcWindow
import com.example.model.Sender
import com.example.model.SystemMetrics
import com.example.model.UserProfile
import com.example.model.VirtualMachineState
import com.example.model.VmSnapshot
import com.example.model.VmStatus
import com.example.service.AuthService
import com.example.service.GeminiClient
import com.example.service.HolyAiSystemContext
import com.example.service.SoundEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.TimeUnit
import android.content.Intent
import android.graphics.Bitmap
import androidx.core.graphics.drawable.toBitmap

class PcSystemViewModel : ViewModel() {

    // Real installed apps on the device (for the "Device Apps" launcher)
    data class DeviceApp(
        val label: String,
        val packageName: String,
        val icon: Bitmap?
    )

    private val _deviceApps = MutableStateFlow<List<DeviceApp>>(emptyList())
    val deviceApps: StateFlow<List<DeviceApp>> = _deviceApps.asStateFlow()

    private val _isLoadingDeviceApps = MutableStateFlow(false)
    val isLoadingDeviceApps: StateFlow<Boolean> = _isLoadingDeviceApps.asStateFlow()

    /** Queries the device's real PackageManager for launchable apps. Genuine device data, not simulated. */
    fun loadDeviceApps(context: Context) {
        if (_isLoadingDeviceApps.value) return
        _isLoadingDeviceApps.value = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val pm = context.packageManager
                val intent = Intent(Intent.ACTION_MAIN, null).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                val resolveInfos = pm.queryIntentActivities(intent, 0)
                val result = resolveInfos.mapNotNull { ri ->
                    try {
                        val label = ri.loadLabel(pm).toString()
                        val pkg = ri.activityInfo.packageName
                        val icon = try {
                            ri.loadIcon(pm).toBitmap(width = 96, height = 96)
                        } catch (e: Exception) {
                            null
                        }
                        DeviceApp(label = label, packageName = pkg, icon = icon)
                    } catch (e: Exception) {
                        null
                    }
                }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
                _deviceApps.value = result
            } catch (e: Exception) {
                _deviceApps.value = emptyList()
            } finally {
                _isLoadingDeviceApps.value = false
            }
        }
    }

    /**
     * "Windows 11 style" smart launch: for icons that have a genuine real-world counterpart
     * (browser, files, media), this launches the REAL installed app via Intent.
     * For everything else (the simulated OS pieces like Terminal, HolyVM, Task Manager),
     * it falls back to opening the normal in-app window.
     */
    fun openAppSmart(context: Context, appId: String) {
        val launched = when (appId) {
            "browser" -> tryLaunchByPackages(context, listOf("com.android.chrome", "com.google.android.apps.chrome"))
                ?: tryLaunchGenericIntent(context, Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com")))
            "file_explorer" -> tryLaunchByPackages(
                context,
                listOf(
                    "com.google.android.documentsui",
                    "com.google.android.apps.nbu.files",
                    "com.android.fileexplorer",
                    "com.sec.android.app.myfiles"
                )
            )
            "media_player" -> tryLaunchByCategory(context, Intent.CATEGORY_APP_MUSIC)
                ?: tryLaunchByPackages(context, listOf("com.google.android.apps.youtube.music", "com.spotify.music"))
            "paint" -> tryLaunchByCategory(context, Intent.CATEGORY_APP_GALLERY)
                ?: tryLaunchByPackages(context, listOf("com.google.android.apps.photos", "com.android.gallery3d"))
            else -> false
        }
        if (!launched) {
            // No matching real app found (or this icon represents a simulated OS piece) — use the in-app window.
            openApp(appId)
        }
    }

    private fun tryLaunchByPackages(context: Context, packages: List<String>): Boolean {
        for (pkg in packages) {
            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return true
            }
        }
        return false
    }

    private fun tryLaunchByCategory(context: Context, category: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(category) }
            val resolved = context.packageManager.queryIntentActivities(intent, 0)
            if (resolved.isNotEmpty()) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else false
        } catch (e: Exception) {
            false
        }
    }

    private fun tryLaunchGenericIntent(context: Context, intent: Intent): Boolean {
        return try {
            if (intent.resolveActivity(context.packageManager) != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else false
        } catch (e: Exception) {
            false
        }
    }


    /** Actually launches a real installed app on the device via a genuine Android Intent. */
    fun launchDeviceApp(context: Context, packageName: String) {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        }
    }

    /** Executes a real shell command on the device (sandboxed to this app's own permissions — no root). */
    private suspend fun runRealShellCommand(command: String): List<String> = withContext(Dispatchers.IO) {
        val output = mutableListOf<String>()
        try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val finished = process.waitFor(10, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                output.add("[Command timed out after 10s]")
            } else {
                process.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { output.add(it) }
                }
                if (output.isEmpty()) output.add("[No output]")
                output.add("[Exit code: ${process.exitValue()}]")
            }
        } catch (e: Exception) {
            output.add("[Error: ${e.message}]")
        }
        output
    }

    // User Profile & Google Authentication State
    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    // Virtual Machine State
    private val _vmState = MutableStateFlow(VirtualMachineState())
    val vmState: StateFlow<VirtualMachineState> = _vmState.asStateFlow()

    // Initial PC Apps Catalog
    private val defaultApps = listOf(
        PcApp(
            id = "holy_ai",
            name = "Holy Stunner AI",
            iconName = "smart_toy",
            description = "Built-in Omnipotent PC AI Copilot with Emulated PC Environment Access",
            category = AppCategory.SYSTEM,
            sizeMb = 48,
            version = "3.5 Ultra",
            isInstalled = true,
            isDefault = true,
            accentColor = 0xFF8B5CF6,
            defaultWidth = 580f,
            defaultHeight = 520f
        ),
        PcApp(
            id = "compat_lab",
            name = "PC Compatibility Lab",
            iconName = "tune",
            description = "Multi-Architecture PC Program Runner, Win32 API Tracing & Testing Sandbox",
            category = AppCategory.PRODUCTIVITY,
            sizeMb = 64,
            version = "3.0",
            isInstalled = true,
            isDefault = true,
            accentColor = 0xFF06B6D4,
            defaultWidth = 660f,
            defaultHeight = 520f
        ),
        PcApp(
            id = "vm_hypervisor",
            name = "HolyVM Hypervisor",
            iconName = "memory",
            description = "16-Core Virtual Machine Architecture, VMM Paging & Storage Subsystem",
            category = AppCategory.SYSTEM,
            sizeMb = 36,
            version = "4.2",
            isInstalled = true,
            isDefault = true,
            accentColor = 0xFF10B981,
            defaultWidth = 640f,
            defaultHeight = 500f
        ),
        PcApp(
            id = "real_apps",
            name = "My Phone Apps",
            iconName = "apps",
            description = "Real Launcher — browse and open apps actually installed on your device",
            category = AppCategory.SYSTEM,
            sizeMb = 1,
            version = "1.0",
            isInstalled = true,
            isDefault = true,
            accentColor = 0xFFF472B6,
            defaultWidth = 620f,
            defaultHeight = 480f
        ),
        PcApp(
            id = "app_installer",
            name = "Software Hub",
            iconName = "storefront",
            description = "PC App Installer & .EXE Package Marketplace",
            category = AppCategory.SYSTEM,
            sizeMb = 32,
            version = "2.4",
            isInstalled = true,
            isDefault = true,
            accentColor = 0xFF06B6D4,
            defaultWidth = 620f,
            defaultHeight = 460f
        ),
        PcApp(
            id = "file_explorer",
            name = "File Explorer",
            iconName = "folder",
            description = "Virtual C: Drive & PC File Manager",
            category = AppCategory.SYSTEM,
            sizeMb = 24,
            version = "11.0",
            isInstalled = true,
            isDefault = true,
            accentColor = 0xFFF59E0B,
            defaultWidth = 600f,
            defaultHeight = 420f
        ),
        PcApp(
            id = "terminal",
            name = "Stunner CMD",
            iconName = "terminal",
            description = "PC Command Prompt & Script Execution Shell",
            category = AppCategory.PRODUCTIVITY,
            sizeMb = 18,
            version = "4.2",
            isInstalled = true,
            isDefault = true,
            accentColor = 0xFF10B981,
            defaultWidth = 580f,
            defaultHeight = 400f
        ),
        PcApp(
            id = "code_editor",
            name = "VS Code Pro",
            iconName = "code",
            description = "Full PC Code Editor with Python & Web Runtime",
            category = AppCategory.PRODUCTIVITY,
            sizeMb = 120,
            version = "1.92",
            isInstalled = true,
            isDefault = false,
            accentColor = 0xFF3B82F6,
            defaultWidth = 640f,
            defaultHeight = 480f
        ),
        PcApp(
            id = "browser",
            name = "Stunner Chrome",
            iconName = "public",
            description = "Ultra-Fast PC Web Browser & Search Engine",
            category = AppCategory.MEDIA,
            sizeMb = 85,
            version = "128.0",
            isInstalled = true,
            isDefault = false,
            accentColor = 0xFFEF4444,
            defaultWidth = 640f,
            defaultHeight = 480f
        ),
        PcApp(
            id = "paint",
            name = "Paint Studio",
            iconName = "brush",
            description = "Digital Canvas & Graphics Design Studio",
            category = AppCategory.CREATIVE,
            sizeMb = 45,
            version = "3.1",
            isInstalled = true,
            isDefault = false,
            accentColor = 0xFFEC4899,
            defaultWidth = 580f,
            defaultHeight = 440f
        ),
        PcApp(
            id = "media_player",
            name = "VLC Cyber Player",
            iconName = "music_note",
            description = "High Fidelity PC Audio & Media Visualizer",
            category = AppCategory.MEDIA,
            sizeMb = 60,
            version = "3.0",
            isInstalled = true,
            isDefault = false,
            accentColor = 0xFFF97316,
            defaultWidth = 520f,
            defaultHeight = 400f
        ),
        PcApp(
            id = "minesweeper",
            name = "Minesweeper 3D",
            iconName = "grid_view",
            description = "Classic PC Logic Mine Disarming Game",
            category = AppCategory.GAMES,
            sizeMb = 20,
            version = "1.5",
            isInstalled = true,
            isDefault = false,
            accentColor = 0xFF14B8A6,
            defaultWidth = 460f,
            defaultHeight = 460f
        ),
        PcApp(
            id = "space_invaders",
            name = "Cyber Invaders",
            iconName = "sports_esports",
            description = "Retro 80s Arcade Space Shooter for PC",
            category = AppCategory.GAMES,
            sizeMb = 28,
            version = "2.0",
            isInstalled = false,
            isDefault = false,
            accentColor = 0xFFA855F7,
            defaultWidth = 500f,
            defaultHeight = 480f
        ),
        PcApp(
            id = "task_manager",
            name = "Task Manager",
            iconName = "monitoring",
            description = "CPU, RAM & Process Health Monitor",
            category = AppCategory.SYSTEM,
            sizeMb = 15,
            version = "2.0",
            isInstalled = true,
            isDefault = true,
            accentColor = 0xFF64748B,
            defaultWidth = 540f,
            defaultHeight = 420f
        ),
        PcApp(
            id = "calculator",
            name = "PC Calculator",
            iconName = "calculate",
            description = "Standard, Scientific & Hex Calculator",
            category = AppCategory.UTILITIES,
            sizeMb = 12,
            version = "2.1",
            isInstalled = true,
            isDefault = true,
            accentColor = 0xFF0284C7,
            defaultWidth = 400f,
            defaultHeight = 480f
        ),
        PcApp(
            id = "settings",
            name = "PC Settings",
            iconName = "settings",
            description = "System Wallpapers, Display & Controls",
            category = AppCategory.SYSTEM,
            sizeMb = 22,
            version = "1.0",
            isInstalled = true,
            isDefault = true,
            accentColor = 0xFF6B7280,
            defaultWidth = 560f,
            defaultHeight = 450f
        )
    )

    private val _apps = MutableStateFlow(defaultApps)
    val apps: StateFlow<List<PcApp>> = _apps.asStateFlow()

    // Windows State
    private val _windows = MutableStateFlow<List<PcWindow>>(emptyList())
    val windows: StateFlow<List<PcWindow>> = _windows.asStateFlow()

    private val _activeWindowId = MutableStateFlow<String?>(null)
    val activeWindowId: StateFlow<String?> = _activeWindowId.asStateFlow()

    // System Metrics
    private val _systemMetrics = MutableStateFlow(SystemMetrics())
    val systemMetrics: StateFlow<SystemMetrics> = _systemMetrics.asStateFlow()

    // Desktop Files
    private val _files = MutableStateFlow(
        listOf(
            PcFileItem(
                id = "f1",
                name = "Welcome_To_HolyStunner_PC.txt",
                path = "C:\\Users\\HolyStunner\\Desktop\\Welcome_To_HolyStunner_PC.txt",
                type = FileType.TEXT,
                content = "Welcome to Holy Stunner PC!\n\nThis is a complete PC emulation environment running inside Android.\nFeatures:\n- Virtual Machine Architecture with 16-Core scheduler and VMM\n- Built-in Holy Stunner AI Copilot with full PC environment access\n- PC Compatibility Lab with Win32 API tracing and guidance\n- Software Hub with installable PC applications\n- Full interactive CMD terminal\n- Code Editor with Python script runner\n- Paint Studio & Classic Games\n- Virtual C: Drive & File Management\n\nEnjoy the next generation of mobile PC computing!",
                iconName = "description"
            ),
            PcFileItem(
                id = "f2",
                name = "matrix_test.py",
                path = "C:\\Users\\HolyStunner\\Desktop\\matrix_test.py",
                type = FileType.PYTHON,
                content = "import time\n\nprint('=== HOLY STUNNER PC QUANTUM TEST ===')\nfor i in range(1, 6):\n    print(f'Thread [{i}]: 100% throughput achieved!')\n    time.sleep(0.3)\nprint('System Status: OPTIMAL')",
                iconName = "code"
            ),
            PcFileItem(
                id = "f3",
                name = "system_health.bat",
                path = "C:\\Users\\HolyStunner\\Desktop\\system_health.bat",
                type = FileType.BATCH,
                content = "@echo off\necho Running Holy Stunner Diagnostics...\nneofetch\necho Battery: 92% | RAM: 16GB DDR5\necho All PC Subsystems Green!",
                iconName = "terminal"
            )
        )
    )
    val files: StateFlow<List<PcFileItem>> = _files.asStateFlow()

    // Desktop Icons
    private val _desktopIcons = MutableStateFlow(
        listOf(
            DesktopIcon(id = "d1", title = "Holy AI", iconName = "smart_toy", appId = "holy_ai", gridCol = 0, gridRow = 0),
            DesktopIcon(id = "d_compat", title = "Compat Lab", iconName = "tune", appId = "compat_lab", gridCol = 0, gridRow = 1),
            DesktopIcon(id = "d_vm", title = "HolyVM", iconName = "memory", appId = "vm_hypervisor", gridCol = 0, gridRow = 2),
            DesktopIcon(id = "d_real_apps", title = "My Phone Apps", iconName = "apps", appId = "real_apps", gridCol = 0, gridRow = 3),
            DesktopIcon(id = "d2", title = "Software Hub", iconName = "storefront", appId = "app_installer", gridCol = 0, gridRow = 4),
            DesktopIcon(id = "d3", title = "File Explorer", iconName = "folder", appId = "file_explorer", gridCol = 0, gridRow = 5),
            DesktopIcon(id = "d4", title = "Terminal CMD", iconName = "terminal", appId = "terminal", gridCol = 0, gridRow = 6),
            DesktopIcon(id = "d5", title = "VS Code Pro", iconName = "code", appId = "code_editor", gridCol = 1, gridRow = 0),
            DesktopIcon(id = "d6", title = "Chrome", iconName = "public", appId = "browser", gridCol = 1, gridRow = 1),
            DesktopIcon(id = "d7", title = "Paint Studio", iconName = "brush", appId = "paint", gridCol = 1, gridRow = 2),
            DesktopIcon(id = "d8", title = "Cyber VLC", iconName = "music_note", appId = "media_player", gridCol = 1, gridRow = 3),
            DesktopIcon(id = "d10", title = "Task Manager", iconName = "monitoring", appId = "task_manager", gridCol = 1, gridRow = 4),
            DesktopIcon(id = "d12", title = "PC Settings", iconName = "settings", appId = "settings", gridCol = 1, gridRow = 5)
        )
    )
    val desktopIcons: StateFlow<List<DesktopIcon>> = _desktopIcons.asStateFlow()

    // UI Overlays
    private val _isStartMenuOpen = MutableStateFlow(false)
    val isStartMenuOpen: StateFlow<Boolean> = _isStartMenuOpen.asStateFlow()

    private val _isQuickSettingsOpen = MutableStateFlow(false)
    val isQuickSettingsOpen: StateFlow<Boolean> = _isQuickSettingsOpen.asStateFlow()

    private val _isCalendarOpen = MutableStateFlow(false)
    val isCalendarOpen: StateFlow<Boolean> = _isCalendarOpen.asStateFlow()

    private val _isBooting = MutableStateFlow(false)
    val isBooting: StateFlow<Boolean> = _isBooting.asStateFlow()

    // Holy AI Chat
    private val _aiMessages = MutableStateFlow(
        listOf(
            HolyAiMessage(
                id = "ai_welcome",
                sender = Sender.HOLY_AI,
                text = "⚡ **Greetings! I am Holy Stunner AI**, your built-in PC copilot with direct hypervisor access to your virtual CPU, RAM, disk, and compatibility engine. How can I assist you today?",
                suggestedCommand = "neofetch"
            )
        )
    )
    val aiMessages: StateFlow<List<HolyAiMessage>> = _aiMessages.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    // Terminal History
    private val _terminalLogs = MutableStateFlow(
        listOf(
            "Holy Stunner PC [Version 11.0.26100.1882]",
            "HolyVM Hypervisor Subsystem [Online - 16 Cores Synchronized]",
            "(c) Holy Stunner Corporation. All rights reserved.",
            "",
            "Type 'help' or 'neofetch' to explore PC commands.",
            ""
        )
    )
    val terminalLogs: StateFlow<List<String>> = _terminalLogs.asStateFlow()

    private var zCounter = 10f

    init {
        viewModelScope.launch {
            while (true) {
                delay(3000)
                _systemMetrics.update { current ->
                    val cpuJitter = (18..36).random()
                    val ramJitter = (3700..4150).random()
                    current.copy(
                        cpuUsagePercent = cpuJitter,
                        ramUsedMb = ramJitter
                    )
                }

                _vmState.update { vm ->
                    val updatedCores = vm.coreMetrics.map { core ->
                        core.copy(
                            loadPercent = (12..40).random(),
                            temperatureC = (40..46).random()
                        )
                    }
                    vm.copy(
                        coreMetrics = updatedCores,
                        uptimeSeconds = vm.uptimeSeconds + 3
                    )
                }
            }
        }
    }

    // Google Sign-In
    fun signInWithGoogle(context: Context) {
        viewModelScope.launch {
            val result = AuthService.signInWithGoogle(context)
            result.onSuccess { profile ->
                _userProfile.value = profile
                SoundEngine.playSuccess()
            }
        }
    }

    fun updateUserProfile(displayName: String, email: String) {
        _userProfile.update { it.copy(displayName = displayName, email = email) }
        SoundEngine.playSuccess()
    }

    // VM Operations
    fun takeVmSnapshot(name: String) {
        val newSnap = VmSnapshot(
            id = UUID.randomUUID().toString(),
            name = name,
            timestamp = System.currentTimeMillis(),
            ramUsedMb = _vmState.value.usedRamMb,
            description = "User-saved VM state (${_windows.value.size} active windows)"
        )
        _vmState.update { it.copy(snapshots = it.snapshots + newSnap) }
        SoundEngine.playSuccess()
    }

    fun rebootVm() {
        rebootPc()
    }

    // Window Management
    fun openApp(appId: String, payload: Any? = null) {
        SoundEngine.playWindowOpen()
        closeOverlays()

        val existing = _windows.value.find { it.appId == appId }
        if (existing != null) {
            zCounter += 1f
            _windows.update { list ->
                list.map {
                    if (it.id == existing.id) {
                        it.copy(isMinimized = false, zIndex = zCounter, payload = payload ?: it.payload)
                    } else it
                }
            }
            _activeWindowId.value = existing.id
            return
        }

        val app = _apps.value.find { it.id == appId } ?: return
        if (!app.isInstalled) {
            openApp("app_installer", payload = appId)
            return
        }

        zCounter += 1f
        val windowCount = _windows.value.size
        val cascadeOffset = (windowCount % 5) * 24f

        val newWindow = PcWindow(
            id = UUID.randomUUID().toString(),
            appId = app.id,
            title = app.name,
            iconName = app.iconName,
            x = 24f + cascadeOffset,
            y = 24f + cascadeOffset,
            width = app.defaultWidth,
            height = app.defaultHeight,
            zIndex = zCounter,
            payload = payload
        )

        _windows.update { it + newWindow }
        _activeWindowId.value = newWindow.id
    }

    fun closeWindow(windowId: String) {
        SoundEngine.playWindowClose()
        _windows.update { it.filterNot { w -> w.id == windowId } }
        if (_activeWindowId.value == windowId) {
            _activeWindowId.value = _windows.value.maxByOrNull { it.zIndex }?.id
        }
    }

    fun minimizeWindow(windowId: String) {
        SoundEngine.playClick()
        _windows.update { list ->
            list.map { if (it.id == windowId) it.copy(isMinimized = true) else it }
        }
        if (_activeWindowId.value == windowId) {
            _activeWindowId.value = _windows.value.filter { !it.isMinimized }.maxByOrNull { it.zIndex }?.id
        }
    }

    fun toggleMaximizeWindow(windowId: String) {
        SoundEngine.playClick()
        _windows.update { list ->
            list.map { if (it.id == windowId) it.copy(isMaximized = !it.isMaximized) else it }
        }
        bringToFront(windowId)
    }

    fun focusWindow(windowId: String) = bringToFront(windowId)

    fun bringToFront(windowId: String) {
        zCounter += 1f
        _windows.update { list ->
            list.map {
                if (it.id == windowId) it.copy(zIndex = zCounter, isMinimized = false) else it
            }
        }
        _activeWindowId.value = windowId
    }

    fun moveWindow(windowId: String, newX: Float, newY: Float) = updateWindowPosition(windowId, newX, newY)

    fun updateWindowPosition(windowId: String, newX: Float, newY: Float) {
        _windows.update { list ->
            list.map { if (it.id == windowId) it.copy(x = newX.coerceAtLeast(0f), y = newY.coerceAtLeast(0f)) else it }
        }
    }

    fun resizeWindow(windowId: String, newWidth: Float, newHeight: Float) = updateWindowSize(windowId, newWidth, newHeight)

    fun updateWindowSize(windowId: String, newWidth: Float, newHeight: Float) {
        _windows.update { list ->
            list.map {
                if (it.id == windowId) {
                    it.copy(
                        width = newWidth.coerceIn(320f, 1000f),
                        height = newHeight.coerceIn(240f, 800f)
                    )
                } else it
            }
        }
    }

    // App Installer Logic
    fun installApp(appId: String) {
        viewModelScope.launch {
            val target = _apps.value.find { it.id == appId } ?: return@launch
            if (target.isInstalled || target.isInstalling) return@launch

            _apps.update { list ->
                list.map { if (it.id == appId) it.copy(isInstalling = true, installProgress = 0f) else it }
            }

            for (step in 1..10) {
                delay(180)
                _apps.update { list ->
                    list.map { if (it.id == appId) it.copy(installProgress = step * 0.1f) else it }
                }
            }

            _apps.update { list ->
                list.map {
                    if (it.id == appId) it.copy(
                        isInstalled = true,
                        isInstalling = false,
                        installProgress = 1.0f
                    ) else it
                }
            }

            // Also add desktop shortcut icon
            val existingIcon = _desktopIcons.value.find { it.appId == appId }
            if (existingIcon == null) {
                val newIcon = DesktopIcon(
                    id = "icon_${target.id}",
                    title = target.name,
                    iconName = target.iconName,
                    appId = target.id,
                    gridCol = 1,
                    gridRow = _desktopIcons.value.size % 6
                )
                _desktopIcons.update { it + newIcon }
            }

            SoundEngine.playSuccess()
        }
    }

    fun uninstallApp(appId: String) {
        val target = _apps.value.find { it.id == appId } ?: return
        if (target.isDefault) return
        _apps.update { list ->
            list.map { if (it.id == appId) it.copy(isInstalled = false, installProgress = 0f) else it }
        }
        _desktopIcons.update { it.filterNot { icon -> icon.appId == appId } }
        val win = _windows.value.find { it.appId == appId }
        if (win != null) closeWindow(win.id)
    }

    fun createCustomApp(name: String, description: String, category: AppCategory) {
        viewModelScope.launch {
            val cleanId = name.lowercase().replace(" ", "_").replace(".exe", "")
            val newApp = PcApp(
                id = cleanId,
                name = name,
                iconName = "widgets",
                description = description,
                category = category,
                sizeMb = (15..80).random(),
                version = "1.0",
                isInstalled = false,
                isDefault = false,
                accentColor = 0xFF06B6D4,
                defaultWidth = 560f,
                defaultHeight = 440f
            )
            _apps.update { it + newApp }
            installApp(cleanId)
        }
    }

    // Holy AI Assistant Actions
    fun sendHolyAiMessage(prompt: String) = sendAiPrompt(prompt)

    fun sendAiPrompt(prompt: String) {
        if (prompt.isBlank()) return
        val userMsg = HolyAiMessage(
            id = UUID.randomUUID().toString(),
            sender = Sender.USER,
            text = prompt
        )
        _aiMessages.update { it + userMsg }
        _isAiThinking.value = true
        SoundEngine.playClick()

        viewModelScope.launch {
            val systemContext = HolyAiSystemContext(
                userProfile = _userProfile.value,
                vmState = _vmState.value,
                metrics = _systemMetrics.value,
                installedApps = _apps.value.filter { it.isInstalled },
                openWindows = _windows.value.filter { !it.isMinimized },
                desktopFiles = _files.value
            )

            val responseText = GeminiClient.queryHolyAiWithSystemContext(prompt, systemContext)
            _isAiThinking.value = false

            val codeBlockRegex = "```(\\w*)\\n([\\s\\S]*?)```".toRegex()
            val codeMatch = codeBlockRegex.find(responseText)
            val codeSnippet = codeMatch?.groups?.get(2)?.value
            val codeLang = codeMatch?.groups?.get(1)?.value?.ifBlank { "python" }

            val cleanText = responseText.replace(codeBlockRegex, "").trim()
            val suggestedCmd = when {
                "neofetch" in prompt.lowercase() || "specs" in prompt.lowercase() -> "neofetch"
                "matrix" in prompt.lowercase() -> "matrix"
                "benchmark" in prompt.lowercase() -> "benchmark"
                "install" in prompt.lowercase() -> "install"
                else -> null
            }

            val aiMsg = HolyAiMessage(
                id = UUID.randomUUID().toString(),
                sender = Sender.HOLY_AI,
                text = if (cleanText.isBlank()) "⚡ **Code Generated Successfully:**" else cleanText,
                codeSnippet = codeSnippet,
                codeLanguage = codeLang,
                suggestedCommand = suggestedCmd
            )
            _aiMessages.update { it + aiMsg }
            SoundEngine.playSuccess()
        }
    }

    // Terminal Commands
    fun executeTerminalCommand(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return

        val parts = trimmed.split(" ")
        val command = parts.first().lowercase()
        val args = parts.drop(1)

        val newLines = mutableListOf<String>()
        newLines.add("C:\\Users\\HolyStunner> $trimmed")

        when (command) {
            "sh", "shell", "exec" -> {
                val realCommand = args.joinToString(" ")
                if (realCommand.isBlank()) {
                    newLines.add("Usage: sh <real device command>  (e.g. sh ls, sh whoami, sh ps)")
                    newLines.add("Runs an actual shell command on this device, sandboxed to this app.")
                } else {
                    newLines.add("[REAL SHELL] Executing on device: $realCommand")
                    _terminalLogs.update { it + newLines }
                    viewModelScope.launch {
                        val output = runRealShellCommand(realCommand)
                        _terminalLogs.update { it + output + "" }
                    }
                    return
                }
            }
            "help" -> {
                newLines.add("HOLY STUNNER PC COMMANDS:")
                newLines.add("  sh <command>  - [REAL] Run an actual shell command on this device")
                newLines.add("  neofetch      - Show PC specs, OS build & ASCII logo")
                newLines.add("  matrix        - Activate cyber digital matrix stream")
                newLines.add("  dir / ls      - List directory files & folders")
                newLines.add("  cat <file>    - Print file content to terminal")
                newLines.add("  python <file> - Run virtual Python script")
                newLines.add("  ai <prompt>   - Query Holy Stunner AI directly")
                newLines.add("  install <app> - Install PC application from Software Hub")
                newLines.add("  benchmark     - Run CPU multithread stress benchmark")
                newLines.add("  compat        - Launch PC Program Compatibility Lab")
                newLines.add("  vmm           - Inspect Virtual Memory Manager")
                newLines.add("  calc <expr>   - Quick arithmetic calculator")
                newLines.add("  cls / clear   - Clear terminal screen")
                newLines.add("  exit          - Close terminal window")
            }
            "cls", "clear" -> {
                _terminalLogs.value = listOf("Holy Stunner PC Terminal [Ready]", "")
                return
            }
            "compat" -> {
                newLines.add("Launching PC Program Compatibility Lab & Testing Suite...")
                openApp("compat_lab")
            }
            "vmm", "vm" -> {
                newLines.add("Opening HolyVM Hypervisor & Virtual Architecture...")
                openApp("vm_hypervisor")
            }
            "neofetch" -> {
                newLines.add("   ██╗  ██╗ ██████╗ ██╗  ██╗   OS: Holy Stunner PC OS x86_64")
                newLines.add("   ██║  ██║██╔════╝ ██║  ██║   Host: HolyVM Hypervisor 4.2 (VT-x/ARM64)")
                newLines.add("   ███████║██║  ███╗███████║   Kernel: 6.12.4-holystunner-zen (NT 10.0)")
                newLines.add("   ██╔══██║██║   ██║██╔══██║   User: ${_userProfile.value.displayName} (${_userProfile.value.email})")
                newLines.add("   ██║  ██║╚██████╔╝██║  ██║   Packages: ${_apps.value.count { it.isInstalled }} Installed")
                newLines.add("   ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝   CPU: 16x Neural Quantum Core @ 4.8GHz")
                newLines.add("                               Memory: ${_systemMetrics.value.ramUsedMb}MiB / 16384MiB (DDR5)")
                newLines.add("                               Storage: C:\\ NVMe (512 GB DMA Enabled)")
            }
            "matrix" -> {
                newLines.add("01001000 01101111 01101100 01111001 00100000 01010011 01110101")
                newLines.add("01101110 01101110 01100101 01110010 00100000 01010000 01000011 00100000")
                newLines.add("[MATRIX OVERLOAD] Access Granted. Neural Link Synchronized.")
            }
            "dir", "ls" -> {
                newLines.add(" Directory of C:\\Users\\HolyStunner\\Desktop")
                newLines.add("")
                _files.value.forEach {
                    newLines.add(String.format("%-12s %8d bytes   %s", it.type.name, it.sizeBytes, it.name))
                }
            }
            "cat" -> {
                val filename = args.joinToString(" ")
                val file = _files.value.find { it.name.equals(filename, ignoreCase = true) }
                if (file != null) {
                    newLines.addAll(file.content.lines())
                } else {
                    newLines.add("File not found: $filename")
                }
            }
            "python" -> {
                val script = args.joinToString(" ")
                newLines.add("Executing Python runtime for [$script]...")
                newLines.add("[OUT] Python 3.12.4 (Virtual Stunner Interpreter)")
                newLines.add("[OUT] >>> Initializing modules...")
                newLines.add("[OUT] >>> Test output: OK (Execution time: 0.042s)")
            }
            "ai" -> {
                val prompt = args.joinToString(" ")
                if (prompt.isNotBlank()) {
                    newLines.add("[HOLY AI QUERYING] Please check Holy Stunner AI Assistant window.")
                    sendAiPrompt(prompt)
                    openApp("holy_ai")
                } else {
                    newLines.add("Usage: ai <your question or task>")
                }
            }
            "install" -> {
                val appQuery = args.joinToString(" ")
                val appToInstall = _apps.value.find {
                    it.name.contains(appQuery, ignoreCase = true) || it.id.contains(appQuery, ignoreCase = true)
                }
                if (appToInstall != null) {
                    newLines.add("Installing ${appToInstall.name} (${appToInstall.version})...")
                    installApp(appToInstall.id)
                    newLines.add("Package successfully downloaded & registered.")
                } else {
                    newLines.add("Package '$appQuery' not found. Available packages: ${apps.value.filter { !it.isInstalled }.joinToString { it.name }}")
                }
            }
            "benchmark" -> {
                newLines.add("Running CPU & Memory Stress Benchmark...")
                newLines.add("Single Core Score: 3,420 pts")
                newLines.add("Multi Core Score:  38,910 pts [TOP TIER 16-CORE]")
                newLines.add("Memory Bandwidth:  128.4 GB/s")
            }
            "calc" -> {
                val expr = args.joinToString("")
                try {
                    val res = when {
                        "+" in expr -> {
                            val parts = expr.split("+")
                            parts[0].toDouble() + parts[1].toDouble()
                        }
                        "-" in expr -> {
                            val parts = expr.split("-")
                            parts[0].toDouble() - parts[1].toDouble()
                        }
                        "*" in expr -> {
                            val parts = expr.split("*")
                            parts[0].toDouble() * parts[1].toDouble()
                        }
                        "/" in expr -> {
                            val parts = expr.split("/")
                            parts[0].toDouble() / parts[1].toDouble()
                        }
                        else -> expr.toDoubleOrNull() ?: 0.0
                    }
                    newLines.add("Result: $res")
                } catch (e: Exception) {
                    newLines.add("Error evaluating expression: $expr")
                }
            }
            "exit" -> {
                val win = _windows.value.find { it.appId == "terminal" }
                if (win != null) closeWindow(win.id)
                return
            }
            else -> {
                newLines.add("'$command' is not recognized as an internal or external command.")
                newLines.add("Type 'help' for a list of valid commands.")
            }
        }
        newLines.add("")

        _terminalLogs.update { it + newLines }
        SoundEngine.playClick()
    }

    // File Management
    fun createFile(name: String, content: String = "", type: FileType = FileType.TEXT) = createNewFile(name, content, type)

    fun createNewFile(name: String, content: String = "", type: FileType = FileType.TEXT) {
        val newFile = PcFileItem(
            id = UUID.randomUUID().toString(),
            name = name,
            path = "C:\\Users\\HolyStunner\\Desktop\\$name",
            type = type,
            sizeBytes = (content.length * 2).toLong().coerceAtLeast(512),
            content = content,
            iconName = when (type) {
                FileType.PYTHON -> "code"
                FileType.BATCH -> "terminal"
                FileType.IMAGE -> "image"
                else -> "description"
            }
        )
        _files.update { it + newFile }
        SoundEngine.playSuccess()
    }

    fun deleteFile(fileId: String) {
        _files.update { it.filterNot { f -> f.id == fileId } }
        SoundEngine.playClick()
    }

    fun updateFileContent(fileId: String, newContent: String) {
        _files.update { list ->
            list.map {
                if (it.id == fileId) it.copy(content = newContent, sizeBytes = (newContent.length * 2).toLong()) else it
            }
        }
    }

    // Desktop UI Toggles
    fun toggleStartMenu() {
        SoundEngine.playClick()
        _isStartMenuOpen.update { !it }
        if (_isStartMenuOpen.value) {
            _isQuickSettingsOpen.value = false
            _isCalendarOpen.value = false
        }
    }

    fun toggleQuickSettings() {
        SoundEngine.playClick()
        _isQuickSettingsOpen.update { !it }
        if (_isQuickSettingsOpen.value) {
            _isStartMenuOpen.value = false
            _isCalendarOpen.value = false
        }
    }

    fun toggleCalendar() {
        SoundEngine.playClick()
        _isCalendarOpen.update { !it }
        if (_isCalendarOpen.value) {
            _isStartMenuOpen.value = false
            _isQuickSettingsOpen.value = false
        }
    }

    fun closeOverlays() {
        _isStartMenuOpen.value = false
        _isQuickSettingsOpen.value = false
        _isCalendarOpen.value = false
    }

    fun setWallpaper(wallpaperName: String) {
        _systemMetrics.update { it.copy(currentWallpaper = wallpaperName) }
        SoundEngine.playSuccess()
    }

    fun setSoundVolume(volume: Float) = setVolume(volume)

    fun setVolume(volume: Float) {
        _systemMetrics.update { it.copy(soundVolume = volume) }
        SoundEngine.setMuted(volume <= 0.05f)
    }

    fun rebootPc() {
        viewModelScope.launch {
            closeOverlays()
            _windows.value = emptyList()
            _isBooting.value = true
            SoundEngine.playBootChime()
            delay(2500)
            _isBooting.value = false
        }
    }
}
